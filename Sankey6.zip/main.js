/*
 * SAP Analytics Cloud - Custom Sankey Chart Widget
 * Version: 1.0.4
 *
 * CChart-style script methods added:
 *   addDimension(dimensionId, feed)     — add a dimension to a feed via script
 *   removeDimension(dimensionId, feed)  — remove a dimension from a feed via script
 *   addMember(feed, memberId)           — add a measure/member to a feed via script
 *   removeMember(feed, memberId)        — remove a measure/member from a feed via script
 *   getSelections()                     — returns currently selected node/edge
 *   sortByValue(sortOrder)              — sort flows ascending or descending by value
 *   rankBy(topN, rankOrder)             — show only top/bottom N flows by value
 *   removeRanking()                     — clear rankBy filter
 *   setEnabled(enabled)                 — enable/disable all click interactions
 *   setContextMenuVisible(visible)      — show/hide right-click context menu
 *   getDataSource()                     — already in index.json, unchanged
 *
 * Data binding setup in SAC Builder Panel:
 *   Dimensions feed : [0] Source dimension  (e.g. Client Domicile Country)
 *                     [1] Target dimension  (e.g. Financial Transaction Booking Country)
 *   Measures feed   : [0] Flow measure      (e.g. Amount / Transaction Value)
 */

var getScriptPromisify = (src) => {
  const __define = define
  define = undefined
  return new Promise(resolve => {
    $.getScript(src, () => {
      define = __define
      resolve()
    })
  })
}

;(function () {

  /* ─────────────────────────────────────────────
   *  Distinct color palette — auto-assigned per node
   * ───────────────────────────────────────────── */
  const NODE_COLORS = [
    '#5470C6', '#91CC75', '#FAC858', '#EE6666', '#73C0DE',
    '#3BA272', '#FC8452', '#9A60B4', '#EA7CCC', '#48B8D0',
    '#F4A261', '#2A9D8F', '#E76F51', '#264653', '#A8DADC',
    '#E9C46A', '#457B9D', '#E63946', '#06D6A0', '#FFB703'
  ]

  /* ─────────────────────────────────────────────
   *  Format a number as a readable amount string
   * ───────────────────────────────────────────── */
  const formatAmount = (val) => {
    if (val == null) return ''
    if (Math.abs(val) >= 1e9) return (val / 1e9).toFixed(2) + 'B'
    if (Math.abs(val) >= 1e6) return (val / 1e6).toFixed(2) + 'M'
    if (Math.abs(val) >= 1e3) return (val / 1e3).toFixed(1) + 'K'
    return val.toLocaleString(undefined, { maximumFractionDigits: 2 })
  }

  /* ─────────────────────────────────────────────
   *  Metadata parser
   * ───────────────────────────────────────────── */
  const parseMetadata = metadata => {
    const { dimensions: dimensionsMap, mainStructureMembers: measuresMap } = metadata
    const dimensions = []
    for (const key in dimensionsMap) {
      dimensions.push({ key, ...dimensionsMap[key] })
    }
    const measures = []
    for (const key in measuresMap) {
      measures.push({ key, ...measuresMap[key] })
    }
    return { dimensions, measures, dimensionsMap, measuresMap }
  }

  /* ─────────────────────────────────────────────
   *  Original hierarchy helper (single-dim fallback)
   * ───────────────────────────────────────────── */
  const appendTotal = (data) => {
    data = JSON.parse(JSON.stringify(data))
    const superRoot = {
      dimensions_0: { id: 'total', label: 'Total' },
      measures_0:   { raw: 0 }
    }
    data.forEach(d => {
      if (d.dimensions_0.parentId) { return }
      d.dimensions_0.parentId = 'total'
      superRoot.measures_0.raw += d.measures_0.raw
    })
    return [superRoot].concat(data)
  }

  /* ─────────────────────────────────────────────
   *  Build nodes + links from two dimensions
   * ───────────────────────────────────────────── */
  const buildDimToDimChart = (data, sourceDimKey, targetDimKey, measureKey) => {
    const sourceNodeSet = new Map()
    const targetNodeSet = new Map()
    const linkMap       = new Map()
    const nodeValueMap  = new Map()
    let   grandTotal    = 0

    data.forEach(row => {
      const sourceLabel = row[sourceDimKey] && row[sourceDimKey].label
      const targetLabel = row[targetDimKey] && row[targetDimKey].label
      const value       = row[measureKey]   && row[measureKey].raw
      if (!sourceLabel || !targetLabel || !value) { return }

      const srcName = 'SRC_' + sourceLabel
      const tgtName = 'TGT_' + targetLabel

      nodeValueMap.set(srcName, (nodeValueMap.get(srcName) || 0) + value)
      nodeValueMap.set(tgtName, (nodeValueMap.get(tgtName) || 0) + value)
      grandTotal += value

      const linkKey = srcName + '||' + tgtName
      const existing = linkMap.get(linkKey)
      if (existing) {
        existing.value += value
      } else {
        linkMap.set(linkKey, { source: srcName, target: tgtName, value })
      }
    })

    let colorIndex = 0
    nodeValueMap.forEach((nodeTotal, nodeName) => {
      const isSource   = nodeName.startsWith('SRC_')
      const cleanLabel = nodeName.replace(/^SRC_/, '').replace(/^TGT_/, '')
      const pct        = grandTotal > 0
        ? ((nodeTotal / grandTotal) * 100).toFixed(1)
        : '0.0'
      const color = NODE_COLORS[colorIndex % NODE_COLORS.length]
      colorIndex++

      const nodeObj = {
        name:      nodeName,
        depth:     isSource ? 0 : 1,
        itemStyle: { color },
        label: {
          position:  isSource ? 'left' : 'right',
          formatter: () => `${cleanLabel}\n${pct}%`,
          fontSize:  12,
          color:     '#333'
        }
      }
      if (isSource) sourceNodeSet.set(nodeName, nodeObj)
      else          targetNodeSet.set(nodeName, nodeObj)
    })

    const nodes = [...sourceNodeSet.values(), ...targetNodeSet.values()]
    const links = [...linkMap.values()]
    return { nodes, links, grandTotal }
  }

  /* ─────────────────────────────────────────────
   *  Renderer
   * ───────────────────────────────────────────── */
  class Renderer {
    constructor (root) {
      this._root    = root
      this._echart  = null
    }

    async render (dataBinding, props, widgetState) {
      await getScriptPromisify('https://cdnjs.cloudflare.com/ajax/libs/echarts/5.0.0/echarts.min.js')
      this.dispose()

      if (dataBinding.state !== 'success') { return }

      const { data, metadata } = dataBinding
      const { dimensions, measures } = parseMetadata(metadata)
      const [measure] = measures

      const isDimToDim = dimensions.length >= 2

      let nodes, links, grandTotal

      if (isDimToDim) {
        const sourceDim = dimensions[0]
        const targetDim = dimensions[1]
        let   workData  = data

        /* ── Apply rankBy filter if active ── */
        if (widgetState.rankTopN > 0) {
          // Compute per-pair totals first
          const pairTotals = new Map()
          workData.forEach(row => {
            const srcLabel = row[sourceDim.key] && row[sourceDim.key].label
            const tgtLabel = row[targetDim.key] && row[targetDim.key].label
            const val      = row[measure.key]   && row[measure.key].raw
            if (!srcLabel || !tgtLabel || !val) return
            const key = srcLabel + '||' + tgtLabel
            pairTotals.set(key, (pairTotals.get(key) || 0) + val)
          })

          // Sort pairs by value
          const sorted = [...pairTotals.entries()].sort((a, b) =>
            widgetState.rankOrder === 'bottom' ? a[1] - b[1] : b[1] - a[1]
          )

          // Keep only top/bottom N pairs
          const keepPairs = new Set(
            sorted.slice(0, widgetState.rankTopN).map(e => e[0])
          )

          workData = workData.filter(row => {
            const srcLabel = row[sourceDim.key] && row[sourceDim.key].label
            const tgtLabel = row[targetDim.key] && row[targetDim.key].label
            if (!srcLabel || !tgtLabel) return false
            return keepPairs.has(srcLabel + '||' + tgtLabel)
          })
        }

        /* ── Apply sortByValue if active ── */
        if (widgetState.sortOrder) {
          workData = [...workData].sort((a, b) => {
            const valA = (a[measure.key] && a[measure.key].raw) || 0
            const valB = (b[measure.key] && b[measure.key].raw) || 0
            return widgetState.sortOrder === 'ascending'
              ? valA - valB
              : valB - valA
          })
        }

        ;({ nodes, links, grandTotal } = buildDimToDimChart(
          workData,
          sourceDim.key,
          targetDim.key,
          measure.key
        ))
      } else {
        const [dimension] = dimensions
        nodes      = []
        links      = []
        grandTotal = 0
        const augmented = appendTotal(data)
        augmented.forEach(d => {
          const { label, id, parentId } = d[dimension.key]
          const { raw } = d[measure.key]
          grandTotal += raw || 0
          nodes.push({ name: label })
          const dParent = augmented.find(p => p[dimension.key].id === parentId)
          if (dParent) {
            links.push({ source: dParent[dimension.key].label, target: label, value: raw })
          }
        })
      }

      const sourceDimDesc = isDimToDim ? (dimensions[0].description || 'Source') : 'Hierarchy'
      const targetDimDesc = isDimToDim ? (dimensions[1].description || 'Target') : ''
      const measureDesc   = measure.label || measure.description || 'Amount'

      /* ── Rank / sort indicator for title ── */
      let titleSuffix = ''
      if (widgetState.rankTopN > 0) {
        titleSuffix = ` — Top ${widgetState.rankTopN} ${widgetState.rankOrder === 'bottom' ? '(Bottom)' : ''} Flows`
      } else if (widgetState.sortOrder) {
        titleSuffix = widgetState.sortOrder === 'ascending' ? ' ↑' : ' ↓'
      }

      this._echart = echarts.init(this._root)

      this._echart.setOption({
        title: [
          {
            text:      measureDesc + ' Flow Analysis' + titleSuffix,
            left:      'center',
            top:       4,
            textStyle: { fontSize: 14, fontWeight: 'bold', color: '#333' }
          },
          {
            text:      sourceDimDesc,
            left:      '1%',
            top:       28,
            textStyle: { fontSize: 11, color: '#888', fontWeight: 'normal' }
          },
          {
            text:      targetDimDesc,
            right:     '1%',
            top:       28,
            textStyle: { fontSize: 11, color: '#888', fontWeight: 'normal' }
          },
          {
            text:      'Total: ' + formatAmount(grandTotal),
            right:     '1%',
            bottom:    4,
            textStyle: { fontSize: 11, fontWeight: 'bold', color: '#555' }
          }
        ],

        tooltip: {
          trigger:   'item',
          triggerOn: 'mousemove',
          formatter: (params) => {
            if (params.dataType === 'edge') {
              const src = params.data.source.replace(/^SRC_/, '')
              const tgt = params.data.target.replace(/^TGT_/, '')
              const val = params.data.value
              const pct = grandTotal > 0
                ? ((val / grandTotal) * 100).toFixed(1)
                : '0.0'
              return [
                `<b>${src}</b> → <b>${tgt}</b>`,
                `Amount: <b>${formatAmount(val)}</b>`,
                `Share: <b>${pct}%</b> of total`
              ].join('<br/>')
            }
            if (params.dataType === 'node') {
              const cleanName = (params.data.name || '')
                .replace(/^SRC_/, '').replace(/^TGT_/, '')
              const isSource = (params.data.name || '').startsWith('SRC_')
              return `<b>${cleanName}</b><br/><span style="color:#888">${isSource ? sourceDimDesc : targetDimDesc}</span>`
            }
            return params.name
          }
        },

        series: [{
          type:     'sankey',
          top:      55,
          bottom:   25,
          data:     nodes,
          links:    links,
          emphasis: { focus: 'adjacency' },
          // Silent mode when disabled
          silent:   !widgetState.enabled,
          label: {
            show:     true,
            fontSize: 12,
            formatter: (params) => (params.name || '')
              .replace(/^SRC_/, '').replace(/^TGT_/, '')
          },
          levels: [
            { depth: 0, lineStyle: { color: 'source', opacity: props.depth0Settings.lineOpacity } },
            { depth: 1, lineStyle: { color: 'source', opacity: props.depth1Settings.lineOpacity } },
            { depth: 2, lineStyle: { color: 'source', opacity: props.depth2Settings.lineOpacity } },
            { depth: 3, lineStyle: { color: 'source', opacity: props.depth3Settings.lineOpacity } }
          ],
          lineStyle: { curveness: 0.7 }
        }]
      })

      /* ── Context menu ── */
      this._removeContextMenu()
      if (widgetState.contextMenuVisible) {
        this._root.addEventListener('contextmenu', this._onContextMenu.bind(this, dataBinding, props, widgetState, isDimToDim, dimensions, grandTotal))
      }

      /* ── Click / linked-analysis handler ── */
      if (widgetState.enabled) {
        this._echart.on('click', (params) => {
          // Track selection for getSelections()
          widgetState.currentSelection = params

          const linkedAnalysis = props['dataBindings']
            .getDataBinding('dataBinding')
            .getLinkedAnalysis()

          if (isDimToDim) {
            const sourceDim = dimensions[0]
            const targetDim = dimensions[1]

            if (params.dataType === 'node') {
              const rawName   = (params.data.name || '')
              const isSource  = rawName.startsWith('SRC_')
              const cleanName = rawName.replace(/^SRC_/, '').replace(/^TGT_/, '')
              const dim       = isSource ? sourceDim : targetDim

              const hit = dataBinding.data.find(row => row[dim.key].label === cleanName)
              if (hit) {
                const selection = {}
                selection[dim.id] = hit[dim.key].id
                linkedAnalysis.setFilters(selection)
              } else {
                linkedAnalysis.removeFilters()
              }

            } else if (params.dataType === 'edge') {
              const srcName = (params.data.source || '').replace(/^SRC_/, '')
              const tgtName = (params.data.target || '').replace(/^TGT_/, '')

              const srcRow = dataBinding.data.find(row => row[sourceDim.key].label === srcName)
              const tgtRow = dataBinding.data.find(row => row[targetDim.key].label === tgtName)

              if (srcRow && tgtRow) {
                const selection = {}
                selection[sourceDim.id] = srcRow[sourceDim.key].id
                selection[targetDim.id] = tgtRow[targetDim.key].id
                linkedAnalysis.setFilters(selection)
              } else {
                linkedAnalysis.removeFilters()
              }
            } else {
              linkedAnalysis.removeFilters()
            }

          } else {
            const [dimension] = dimensions
            const label = params.dataType === 'node'
              ? params.data.name
              : params.dataType === 'edge' ? params.data.target : ''
            const selectedItem = dataBinding.data.find(item => item[dimension.key].label === label)
            if (selectedItem) {
              const selection = {}
              selection[dimension.id] = selectedItem[dimension.key].id
              linkedAnalysis.setFilters(selection)
            } else {
              linkedAnalysis.removeFilters()
            }
          }
        })
      }
    }

    /* ── Context menu builder ── */
    _onContextMenu (dataBinding, props, widgetState, isDimToDim, dimensions, grandTotal, event) {
      event.preventDefault()
      this._removeContextMenuEl()

      const menu = document.createElement('div')
      menu.id = '__sankeyContextMenu'
      menu.style.cssText = `
        position:fixed; z-index:9999; background:#fff; border:1px solid #ddd;
        border-radius:6px; box-shadow:0 4px 16px rgba(0,0,0,0.15);
        font-family:sans-serif; font-size:13px; min-width:180px; overflow:hidden;
      `
      menu.style.left = event.clientX + 'px'
      menu.style.top  = event.clientY + 'px'

      const items = [
        { label: '↑ Sort by Value (High → Low)', action: () => { widgetState.sortOrder = 'descending'; widgetState.rankTopN = 0; this._triggerRerender(props, widgetState) } },
        { label: '↓ Sort by Value (Low → High)', action: () => { widgetState.sortOrder = 'ascending';  widgetState.rankTopN = 0; this._triggerRerender(props, widgetState) } },
        { label: '⬛ Clear Sort / Ranking',        action: () => { widgetState.sortOrder = null; widgetState.rankTopN = 0; this._triggerRerender(props, widgetState) } },
        { label: '🏆 Top 5 Flows',                 action: () => { widgetState.rankTopN = 5;  widgetState.rankOrder = 'top'; widgetState.sortOrder = null; this._triggerRerender(props, widgetState) } },
        { label: '🏆 Top 10 Flows',                action: () => { widgetState.rankTopN = 10; widgetState.rankOrder = 'top'; widgetState.sortOrder = null; this._triggerRerender(props, widgetState) } },
      ]

      items.forEach(item => {
        const el = document.createElement('div')
        el.textContent = item.label
        el.style.cssText = 'padding:9px 16px; cursor:pointer; border-bottom:1px solid #f0f0f0;'
        el.addEventListener('mouseenter', () => el.style.background = '#f5f5f5')
        el.addEventListener('mouseleave', () => el.style.background = '')
        el.addEventListener('click', () => { item.action(); this._removeContextMenuEl() })
        menu.appendChild(el)
      })

      document.body.appendChild(menu)
      // Close on outside click
      setTimeout(() => {
        document.addEventListener('click', () => this._removeContextMenuEl(), { once: true })
      }, 0)
    }

    _triggerRerender (props, widgetState) {
      // Dispatch a propertiesChanged event to trigger SAC re-render cycle
      // Since we're inside the renderer (not the custom element), we use the stored ref
      if (this._reRenderCallback) { this._reRenderCallback() }
    }

    _removeContextMenuEl () {
      const el = document.getElementById('__sankeyContextMenu')
      if (el) el.remove()
    }

    _removeContextMenu () {
      this._root.removeEventListener('contextmenu', this._onContextMenu)
      this._removeContextMenuEl()
    }

    dispose () {
      this._removeContextMenuEl()
      if (this._echart) {
        echarts.dispose(this._echart)
      }
    }
  }

  /* ─────────────────────────────────────────────
   *  HTML Template
   * ───────────────────────────────────────────── */
  const template = document.createElement('template')
  template.innerHTML = `
  <style>
    #chart { width: 100%; height: 100%; }
  </style>
  <div id="root" style="width: 100%; height: 100%;">
    <div id="chart"></div>
  </div>
  `

  /* ─────────────────────────────────────────────
   *  Main Custom Element
   * ───────────────────────────────────────────── */
  class Main extends HTMLElement {
    constructor () {
      super()
      this._shadowRoot = this.attachShadow({ mode: 'open' })
      this._shadowRoot.appendChild(template.content.cloneNode(true))
      this._root     = this._shadowRoot.getElementById('root')
      this._props    = {}
      this._renderer = new Renderer(this._root)

      /* ── Widget state — drives all CChart-style methods ── */
      this._widgetState = {
        enabled:              true,   // setEnabled()
        contextMenuVisible:   false,  // setContextMenuVisible()
        sortOrder:            null,   // sortByValue() — 'ascending' | 'descending' | null
        rankTopN:             0,      // rankBy() — 0 = no rank filter
        rankOrder:            'top',  // rankBy() — 'top' | 'bottom'
        currentSelection:     null,   // getSelections() — last clicked params
      }

      // Give renderer a callback to trigger re-render from context menu
      this._renderer._reRenderCallback = () => this.render()
    }

    // ── Lifecycle ──

    async onCustomWidgetBeforeUpdate (changedProps) {
      this._props = { ...this._props, ...changedProps }
    }

    async onCustomWidgetAfterUpdate (changedProps) {
      this.render()
    }

    async onCustomWidgetResize (width, height) {
      this.render()
    }

    async onCustomWidgetDestroy () {
      this.dispose()
    }

    render () {
      if (!document.contains(this)) {
        setTimeout(this.render.bind(this), 0)
        return
      }
      this._renderer.render(this.dataBinding, this._props, this._widgetState)
    }

    dispose () {
      this._renderer.dispose()
    }

    // ────────────────────────────────────────────
    //  CChart-style Script Methods
    //  Called from SAC script editor as:
    //  EChartsSankeyStyling_1.methodName(args)
    // ────────────────────────────────────────────

    /**
     * addDimension(dimensionId, feed)
     * Adds a dimension to the specified feed via SAC DataBinding API.
     * feed: "dimensions" | "measures"
     * Example: EChartsSankeyStyling_1.addDimension("BookingCountry", "dimensions")
     */
    async addDimension (dimensionId, feed) {
      const dataBinding = this._props['dataBindings'].getDataBinding('dataBinding')
      await dataBinding.addDimensionToFeed(feed, dimensionId)
    }

    /**
     * removeDimension(dimensionId, feed)
     * Removes a dimension from the specified feed via SAC DataBinding API.
     * Example: EChartsSankeyStyling_1.removeDimension("BookingCountry", "dimensions")
     */
    async removeDimension (dimensionId, feed) {
      const dataBinding = this._props['dataBindings'].getDataBinding('dataBinding')
      await dataBinding.removeMember(feed, dimensionId)
    }

    /**
     * addMember(feed, memberId)
     * Adds a measure/member to the specified feed via SAC DataBinding API.
     * Example: EChartsSankeyStyling_1.addMember("measures", "Amount")
     */
    async addMember (feed, memberId) {
      const dataBinding = this._props['dataBindings'].getDataBinding('dataBinding')
      await dataBinding.addMemberToFeed(feed, memberId)
    }

    /**
     * removeMember(feed, memberId)
     * Removes a measure/member from the specified feed via SAC DataBinding API.
     * Example: EChartsSankeyStyling_1.removeMember("measures", "Amount")
     */
    async removeMember (feed, memberId) {
      const dataBinding = this._props['dataBindings'].getDataBinding('dataBinding')
      await dataBinding.removeMember(feed, memberId)
    }

    /**
     * getSelections()
     * Returns the last clicked node or edge as a Selection-like object.
     * Returns null if nothing has been clicked yet.
     * Example: var sel = EChartsSankeyStyling_1.getSelections()
     */
    getSelections () {
      const s = this._widgetState.currentSelection
      if (!s) { return null }
      if (s.dataType === 'node') {
        return {
          dataType:  'node',
          name:      (s.data.name || '').replace(/^SRC_/, '').replace(/^TGT_/, ''),
          side:      (s.data.name || '').startsWith('SRC_') ? 'source' : 'target',
          rawName:   s.data.name
        }
      }
      if (s.dataType === 'edge') {
        return {
          dataType: 'edge',
          source:   (s.data.source || '').replace(/^SRC_/, ''),
          target:   (s.data.target || '').replace(/^TGT_/, ''),
          value:    s.data.value
        }
      }
      return null
    }

    /**
     * sortByValue(sortOrder)
     * Sorts the Sankey flows by amount value before rendering.
     * sortOrder: "ascending" | "descending"
     * Example: EChartsSankeyStyling_1.sortByValue("descending")
     */
    sortByValue (sortOrder) {
      this._widgetState.sortOrder = sortOrder
      this._widgetState.rankTopN  = 0   // clear any active ranking
      this.render()
    }

    /**
     * removeSorting()
     * Clears the active sort and restores original data order.
     * Example: EChartsSankeyStyling_1.removeSorting()
     */
    removeSorting () {
      this._widgetState.sortOrder = null
      this.render()
    }

    /**
     * rankBy(topN, rankOrder)
     * Filters to show only the top or bottom N flows by value.
     * topN:      integer — number of flows to show
     * rankOrder: "top" | "bottom"  (default: "top")
     * Example: EChartsSankeyStyling_1.rankBy(5, "top")
     */
    rankBy (topN, rankOrder) {
      this._widgetState.rankTopN   = parseInt(topN, 10) || 5
      this._widgetState.rankOrder  = rankOrder === 'bottom' ? 'bottom' : 'top'
      this._widgetState.sortOrder  = null   // clear sort when ranking
      this.render()
    }

    /**
     * removeRanking()
     * Clears the active Top N filter and shows all flows again.
     * Example: EChartsSankeyStyling_1.removeRanking()
     */
    removeRanking () {
      this._widgetState.rankTopN  = 0
      this._widgetState.rankOrder = 'top'
      this.render()
    }

    /**
     * setEnabled(enabled)
     * Enables or disables all click/hover interactions on the chart.
     * enabled: true | false
     * Example: EChartsSankeyStyling_1.setEnabled(false)
     */
    setEnabled (enabled) {
      this._widgetState.enabled = !!enabled
      this.render()
    }

    /**
     * isEnabled()
     * Returns whether interactions are currently enabled.
     * Example: var enabled = EChartsSankeyStyling_1.isEnabled()
     */
    isEnabled () {
      return this._widgetState.enabled
    }

    /**
     * setContextMenuVisible(visible)
     * Shows or hides the right-click context menu.
     * When visible=true, right-clicking the chart shows sort/rank options.
     * Example: EChartsSankeyStyling_1.setContextMenuVisible(true)
     */
    setContextMenuVisible (visible) {
      this._widgetState.contextMenuVisible = !!visible
      this.render()
    }
  }

  customElements.define('com-sap-sac-sample-echarts-sankeyyg', Main)
})()
