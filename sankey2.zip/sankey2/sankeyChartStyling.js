(function () {

    let template = document.createElement("template");
    template.innerHTML = `
      <style>
        .depthSettings {
          margin: 0.5rem 0;
        }

        .depth {
          font-size: 18px;
        }

        .settings {
          color: #666;
          font-size: 14px;
        }

        .settings label {
          display: inline-block;
          line-height: 1.75rem;
          width: 5.625rem;
        }

        .settings input {
          color: #333;
          line-height: 1.25rem;
        }
      </style>

      <div>

        ${[0,1,2,3].map(depth => `
        <div class="depthSettings">
          <div class="depth">
            <label>Depth ${depth}</label>
          </div>

          <div class="settings">
            <div>
              <label>Color:</label>
              <input id="depth${depth}_itemColor" type="text"/>
            </div>

            <div>
              <label>Line Opacity:</label>
              <input id="depth${depth}_lineOpacity" type="text"/>
            </div>
          </div>
        </div>
        `).join("")}

      </div>
    `;

    class SankeyChartStylingPanel extends HTMLElement {

        constructor() {
            super();

            this._shadowRoot = this.attachShadow({ mode: "open" });
            this._shadowRoot.appendChild(template.content.cloneNode(true));

            this._props = {};

            // attach listeners dynamically
            [0,1,2,3].forEach(depth => {

                this._shadowRoot
                    .getElementById(`depth${depth}_itemColor`)
                    .addEventListener(
                        "change",
                        this.onDepthSettingsChanged.bind(this, depth)
                    );

                this._shadowRoot
                    .getElementById(`depth${depth}_lineOpacity`)
                    .addEventListener(
                        "change",
                        this.onDepthSettingsChanged.bind(this, depth)
                    );
            });
        }

        // ============================
        // SAC Lifecycle
        // ============================

        onCustomWidgetBeforeUpdate(changedProps) {

            this._props = { ...this._props, ...changedProps };

            [0,1,2,3].forEach(depth => {
                if (`depth${depth}Settings` in changedProps) {
                    this.updateDepthSettings(
                        changedProps[`depth${depth}Settings`],
                        depth
                    );
                }
            });
        }

        onCustomWidgetAfterUpdate() {}

        onCustomWidgetDestroy() {}

        // ============================
        // Update UI from SAC props
        // ============================

        updateDepthSettings(settings, depth) {

            this.setColor(depth, settings.itemColor);
            this.setOpacity(depth, settings.lineOpacity);
        }

        // ============================
        // Property Change → SAC
        // ============================

        onDepthSettingsChanged(depth, event) {

            event.preventDefault();

            const properties = {};

            properties[`depth${depth}Settings`] = {
                itemColor: this.getColor(depth),
                lineOpacity: this.getOpacity(depth)
            };

            this.dispatchEvent(new CustomEvent("propertiesChanged", {
                detail: { properties }
            }));
        }

        // ============================
        // Helpers
        // ============================

        setColor(depth, value) {
            this._shadowRoot.getElementById(
                `depth${depth}_itemColor`
            ).value = value;
        }

        getColor(depth) {
            return this._shadowRoot.getElementById(
                `depth${depth}_itemColor`
            ).value;
        }

        setOpacity(depth, value) {
            this._shadowRoot.getElementById(
                `depth${depth}_lineOpacity`
            ).value = value;
        }

        getOpacity(depth) {
            return parseFloat(
                this._shadowRoot.getElementById(
                    `depth${depth}_lineOpacity`
                ).value
            );
        }
    }

    customElements.define(
        "com-sap-sac-sample-echarts-sankeyyg-styling",
        SankeyChartStylingPanel
    );

})();