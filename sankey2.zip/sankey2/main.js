var getScriptPromisify = (src) => {
  const __define = define
  define = undefined
  return new Promise(resolve => {
    $.getScript(src, () => {
      define = __define
      resolve()
    })
  })
}

(function () {

  // ===============================
  // Metadata Parser (UNCHANGED)
  // ===============================
  const parseMetadata = metadata => {

    const { dimensions: dimensionsMap, mainStructureMembers: measuresMap } = metadata

    const dimensions = []
    for (const key in dimensionsMap) {
      dimensions.push({ key, ...dimensionsMap[key] })
    }

    const measures = []
    for (const key in measuresMap) {
      measures.push({ key, ...measuresMap[key] })
    }

    return { dimensions, measures }
  }


  // ===============================
  // Renderer
  // ===============================
  class Renderer {

    constructor(root) {
      this._root = root
      this._echart = null
    }

    async render(dataBinding, props) {

      await getScriptPromisify(
        "https://cdnjs.cloudflare.com/ajax/libs/echarts/5.0.0/echarts.min.js"
      )

      this.dispose()

      if (dataBinding.state !== "success") return

      let { data, metadata } = dataBinding
      const { dimensions, measures } = parseMetadata(metadata)

      if (dimensions.length < 2) return

      const [sourceDim, targetDim] = dimensions
      const [measure] = measures

      const nodes = []
      const links = []

      // ===============================
      // NEW: Dynamic 2-Dimension Logic
      // ===============================

      const nodeSet = new Set()
      const linkMap = {}

      data.forEach(row => {

        const source = row[sourceDim.key]?.label
        const target = row[targetDim.key]?.label
        const value = Number(row[measure.key]?.raw || 0)

        if (!source || !target || value === 0) return

        nodeSet.add(source)
        nodeSet.add(target)

        const key = source + "|" + target

        if (!linkMap[key]) {
          linkMap[key] = {
            source,
            target,
            value: 0
          }
        }

        linkMap[key].value += value
      })

      nodeSet.forEach(n => nodes.push({ name: n }))
      Object.values(linkMap).forEach(l => links.push(l))

      // ===============================
      // Chart
      // ===============================

      this._echart = echarts.init(this._root)

      this._echart.setOption({

        tooltip: {
          trigger: "item",
          triggerOn: "mousemove"
        },

        series: [{
          type: "sankey",
          data: nodes,
          links: links,

          emphasis: { focus: "adjacency" },

          levels: [
            {
              depth: 0,
              itemStyle: {
                color: props.depth0Settings?.itemColor || "#348B26"
              },
              lineStyle: {
                color: "source",
                opacity: props.depth0Settings?.lineOpacity || 0.6
              }
            },
            {
              depth: 1,
              itemStyle: {
                color: props.depth1Settings?.itemColor || "#4FB81C"
              },
              lineStyle: {
                color: "source",
                opacity: props.depth1Settings?.lineOpacity || 0.4
              }
            },
            {
              depth: 2,
              itemStyle: {
                color: props.depth2Settings?.itemColor || "#93C939"
              },
              lineStyle: {
                color: "source",
                opacity: props.depth2Settings?.lineOpacity || 0.2
              }
            },
            {
              depth: 3,
              itemStyle: {
                color: props.depth3Settings?.itemColor || "#BCDC50"
              },
              lineStyle: {
                color: "source",
                opacity: props.depth3Settings?.lineOpacity || 0.1
              }
            }
          ],

          lineStyle: {
            curveness: 0.7
          }
        }]
      })


      // ===============================
      // Linked Analysis (UPDATED)
      // ===============================

      const linkedAnalysis =
        props.dataBindings
          .getDataBinding("dataBinding")
          .getLinkedAnalysis()

      this._echart.on("click", params => {

        if (!linkedAnalysis) return

        const selection = {}

        if (params.dataType === "edge") {

          const { source, target } = params.data

          const match = data.find(r =>
            r[sourceDim.key]?.label === source &&
            r[targetDim.key]?.label === target
          )

          if (!match) return

          selection[sourceDim.id] = match[sourceDim.key].id
          selection[targetDim.id] = match[targetDim.key].id

          linkedAnalysis.setFilters(selection)
        }

        else if (params.dataType === "node") {

          const name = params.data.name

          const match = data.find(r =>
            r[sourceDim.key]?.label === name ||
            r[targetDim.key]?.label === name
          )

          if (!match) return

          if (match[sourceDim.key]?.label === name)
            selection[sourceDim.id] = match[sourceDim.key].id

          if (match[targetDim.key]?.label === name)
            selection[targetDim.id] = match[targetDim.key].id

          linkedAnalysis.setFilters(selection)
        }
      })
    }

    dispose() {
      if (this._echart) echarts.dispose(this._echart)
    }
  }


  // ===============================
  // Web Component
  // ===============================

  const template = document.createElement("template")
  template.innerHTML = `
    <style>
      #chart {
        width: 100%;
        height: 100%;
      }
    </style>
    <div id="root" style="width:100%;height:100%"></div>
  `

  class Main extends HTMLElement {

    constructor() {
      super()

      this.attachShadow({ mode: "open" })
        .appendChild(template.content.cloneNode(true))

      this._root = this.shadowRoot.getElementById("root")
      this._renderer = new Renderer(this._root)
      this._props = {}
    }

    async onCustomWidgetBeforeUpdate(changedProps) {
      this._props = { ...this._props, ...changedProps }
    }

    async onCustomWidgetAfterUpdate() {
      this.render()
    }

    async onCustomWidgetResize() {
      this.render()
    }

    async onCustomWidgetDestroy() {
      this._renderer.dispose()
    }

    render() {
      if (!document.contains(this)) {
        setTimeout(this.render.bind(this), 0)
        return
      }

      this._renderer.render(this.dataBinding, this._props)
    }
  }

  customElements.define(
    "com-sap-sac-sample-echarts-sankeyyg",
    Main
  )

})()