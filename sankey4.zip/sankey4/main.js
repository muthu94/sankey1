/*
 * SAP Analytics Cloud - Custom Sankey Chart Widget
 * Mode: Dimension-to-Dimension flow
 *
 * Data binding setup in SAC Builder Panel:
 *   Dimensions feed : [0] Source dimension  (e.g. Client Domicile Country)
 *                     [1] Target dimension  (e.g. Financial Transaction Booking Country)
 *   Measures feed   : [0] Flow measure      (e.g. Amount / Transaction Value)
 *
 * Each data row is treated as one flow:
 *   dimensions_0.label  -->  dimensions_1.label  with value = measures_0.raw
 *
 * The widget falls back gracefully when only one dimension is bound
 * (original hierarchy / parentId mode is preserved as fallback).
 */

var getScriptPromisify = (src) => {
  // Workaround for conflict between geo widget and echarts.
  const __define = define
  define = undefined
  return new Promise(resolve => {
    $.getScript(src, () => {
      define = __define
      resolve()
    })
  })
}

;(function () {

  /* ─────────────────────────────────────────────
   *  Metadata parser  (unchanged from original)
   * ───────────────────────────────────────────── */
  const parseMetadata = metadata => {
    const { dimensions: dimensionsMap, mainStructureMembers: measuresMap } = metadata
    const dimensions = []
    for (const key in dimensionsMap) {
      const dimension = dimensionsMap[key]
      dimensions.push({ key, ...dimension })
    }
    const measures = []
    for (const key in measuresMap) {
      const measure = measuresMap[key]
      measures.push({ key, ...measure })
    }
    return { dimensions, measures, dimensionsMap, measuresMap }
  }

  /* ─────────────────────────────────────────────
   *  Original hierarchy helper  (kept for fallback)
   * ───────────────────────────────────────────── */
  const appendTotal = (data) => {
    data = JSON.parse(JSON.stringify(data))
    const superRoot = {
      dimensions_0: { id: 'total', label: 'Total' },
      measures_0: { raw: 0 }
    }
    data.forEach(d => {
      if (d.dimensions_0.parentId) { return }
      d.dimensions_0.parentId = 'total'
      superRoot.measures_0.raw += d.measures_0.raw
    })
    return [superRoot].concat(data)
  }

  /* ─────────────────────────────────────────────
   *  NEW: Build nodes + links from two dimensions
   *
   *  Strategy:
   *  - Source nodes  → depth 0  (prefixed internally to avoid
   *    collisions when a country appears on both sides)
   *  - Target nodes  → depth 1
   *  - Each row contributes one link: source → target = measure value
   *  - Rows with null / empty labels are skipped
   *  - When multiple rows share the same source→target pair the
   *    values are aggregated into a single link (ECharts requirement:
   *    duplicate source+target pairs cause rendering errors)
   * ───────────────────────────────────────────── */
  const buildDimToDimChart = (data, sourceDimKey, targetDimKey, measureKey) => {
    const sourceNodeSet = new Map()  // label → node object
    const targetNodeSet = new Map()  // label → node object
    const linkMap = new Map()        // "source||target" → accumulated value

    data.forEach(row => {
      const sourceLabel = row[sourceDimKey] && row[sourceDimKey].label
      const targetLabel = row[targetDimKey] && row[targetDimKey].label
      const value       = row[measureKey]   && row[measureKey].raw

      // Skip rows that are missing any required field or have zero/null value
      if (!sourceLabel || !targetLabel || value == null) { return }

      // Prefix source labels so that e.g. "Germany" as a source and
      // "Germany" as a target are treated as distinct Sankey nodes.
      // The prefix is stripped for the displayed node name via a lookup.
      const sourceNodeName = 'SRC_' + sourceLabel
      const targetNodeName = 'TGT_' + targetLabel

      if (!sourceNodeSet.has(sourceNodeName)) {
        sourceNodeSet.set(sourceNodeName, {
          name: sourceNodeName,
          depth: 0,
          // Keep original label for tooltip / display
          label: { formatter: () => sourceLabel }
        })
      }
      if (!targetNodeSet.has(targetNodeName)) {
        targetNodeSet.set(targetNodeName, {
          name: targetNodeName,
          depth: 1,
          label: { formatter: () => targetLabel }
        })
      }

      // Aggregate duplicate source→target pairs
      const linkKey = sourceNodeName + '||' + targetNodeName
      const existing = linkMap.get(linkKey)
      if (existing) {
        existing.value += value
      } else {
        linkMap.set(linkKey, {
          source: sourceNodeName,
          target: targetNodeName,
          value:  value
        })
      }
    })

    const nodes = [...sourceNodeSet.values(), ...targetNodeSet.values()]
    const links = [...linkMap.values()]

    return { nodes, links }
  }

  /* ─────────────────────────────────────────────
   *  Renderer
   * ───────────────────────────────────────────── */
  class Renderer {
    constructor (root) {
      this._root   = root
      this._echart = null
    }

    async render (dataBinding, props) {
      await getScriptPromisify('https://cdnjs.cloudflare.com/ajax/libs/echarts/5.0.0/echarts.min.js')
      this.dispose()

      if (dataBinding.state !== 'success') { return }

      const { data, metadata } = dataBinding
      const { dimensions, measures } = parseMetadata(metadata)

      const [measure] = measures

      /* ── Decide rendering mode ── */
      const isDimToDim = dimensions.length >= 2

      let nodes, links

      if (isDimToDim) {
        /* ════════════════════════════════════════
         *  TWO-DIMENSION MODE
         *  dimensions[0] = Source  (e.g. Client Domicile Country)
         *  dimensions[1] = Target  (e.g. Booking Country)
         *  measures[0]   = Amount / flow value
         * ════════════════════════════════════════ */
        const sourceDim = dimensions[0]
        const targetDim = dimensions[1]

        ;({ nodes, links } = buildDimToDimChart(
          data,
          sourceDim.key,
          targetDim.key,
          measure.key
        ))
      } else {
        /* ════════════════════════════════════════
         *  ORIGINAL SINGLE-DIMENSION / HIERARCHY MODE  (fallback)
         * ════════════════════════════════════════ */
        const [dimension] = dimensions
        nodes = []
        links = []

        const augmented = appendTotal(data)
        augmented.forEach(d => {
          const { label, id, parentId } = d[dimension.key]
          const { raw } = d[measure.key]
          nodes.push({ name: label })

          const dParent = augmented.find(p => p[dimension.key].id === parentId)
          if (dParent) {
            const { label: labelParent } = dParent[dimension.key]
            links.push({ source: labelParent, target: label, value: raw })
          }
        })
      }

      /* ── Initialise / configure ECharts ── */
      this._echart = echarts.init(this._root)

      this._echart.setOption({
        title: { text: '' },
        tooltip: {
          trigger: 'item',
          triggerOn: 'mousemove',
          formatter: (params) => {
            if (params.dataType === 'edge') {
              // Strip the SRC_ / TGT_ prefixes for a clean tooltip
              const src = params.data.source.replace(/^SRC_/, '')
              const tgt = params.data.target.replace(/^TGT_/, '')
              const val = params.data.value != null
                ? params.data.value.toLocaleString(undefined, { maximumFractionDigits: 2 })
                : ''
              return `${src} → ${tgt}<br/><b>${val}</b>`
            }
            if (params.dataType === 'node') {
              // Strip prefix for node tooltip
              const displayName = (params.data.name || '')
                .replace(/^SRC_/, '')
                .replace(/^TGT_/, '')
              return displayName
            }
            return params.name
          }
        },
        series: [
          {
            type: 'sankey',
            data: nodes,
            links: links,
            emphasis: { focus: 'adjacency' },

            /* ── Node label formatting: strip the SRC_/TGT_ prefix ── */
            label: {
              formatter: (params) => {
                return (params.name || '')
                  .replace(/^SRC_/, '')
                  .replace(/^TGT_/, '')
              }
            },

            levels: [
              {
                depth: 0,
                itemStyle: {
                  color: props.depth0Settings.itemColor || '#348B26'
                },
                lineStyle: {
                  color:   'source',
                  opacity: props.depth0Settings.lineOpacity
                }
              },
              {
                depth: 1,
                itemStyle: {
                  color: props.depth1Settings.itemColor || '#4FB81C'
                },
                lineStyle: {
                  color:   'source',
                  opacity: props.depth1Settings.lineOpacity
                }
              },
              {
                depth: 2,
                itemStyle: {
                  color: props.depth2Settings.itemColor || '#93C939'
                },
                lineStyle: {
                  color:   'source',
                  opacity: props.depth2Settings.lineOpacity
                }
              },
              {
                depth: 3,
                itemStyle: {
                  color: props.depth3Settings.itemColor || '#BCDC50'
                },
                lineStyle: {
                  color:   'source',
                  opacity: props.depth3Settings.lineOpacity
                }
              }
            ],
            lineStyle: { curveness: 0.7 }
          }
        ]
      })

      /* ── Click / linked-analysis handler ── */
      this._echart.on('click', (params) => {
        const linkedAnalysis = props['dataBindings']
          .getDataBinding('dataBinding')
          .getLinkedAnalysis()

        if (isDimToDim) {
          /* In two-dimension mode we filter on whichever dimension node
           * the user clicked. Edge clicks filter on the TARGET dimension. */
          const sourceDim = dimensions[0]
          const targetDim = dimensions[1]

          if (params.dataType === 'node') {
            const rawName   = (params.data.name || '')
            const isSource  = rawName.startsWith('SRC_')
            const cleanName = rawName.replace(/^SRC_/, '').replace(/^TGT_/, '')
            const dim       = isSource ? sourceDim : targetDim
            const dimKey    = dim.key
            const dimId     = dim.id

            const hit = dataBinding.data.find(row => row[dimKey].label === cleanName)
            if (hit) {
              const selection = {}
              selection[dimId] = hit[dimKey].id
              linkedAnalysis.setFilters(selection)
            } else {
              linkedAnalysis.removeFilters()
            }

          } else if (params.dataType === 'edge') {
            // Edge click → filter both dimensions simultaneously
            const srcName = (params.data.source || '').replace(/^SRC_/, '')
            const tgtName = (params.data.target || '').replace(/^TGT_/, '')

            const srcRow = dataBinding.data.find(row => row[sourceDim.key].label === srcName)
            const tgtRow = dataBinding.data.find(row => row[targetDim.key].label === tgtName)

            if (srcRow && tgtRow) {
              const selection = {}
              selection[sourceDim.id] = srcRow[sourceDim.key].id
              selection[targetDim.id] = tgtRow[targetDim.key].id
              linkedAnalysis.setFilters(selection)
            } else {
              linkedAnalysis.removeFilters()
            }

          } else {
            linkedAnalysis.removeFilters()
          }

        } else {
          /* Original single-dimension linked-analysis logic */
          const [dimension] = dimensions
          const dataType    = params.dataType
          const label       = dataType === 'node'
            ? params.data.name
            : dataType === 'edge'
              ? params.data.target
              : ''

          const selectedItem = dataBinding.data.find(item => item[dimension.key].label === label)
          if (selectedItem) {
            const selection = {}
            selection[dimension.id] = selectedItem[dimension.key].id
            linkedAnalysis.setFilters(selection)
          } else {
            linkedAnalysis.removeFilters()
          }
        }
      })
    }

    dispose () {
      if (this._echart) {
        echarts.dispose(this._echart)
      }
    }
  }

  /* ─────────────────────────────────────────────
   *  Web Component template  (unchanged)
   * ───────────────────────────────────────────── */
  const template = document.createElement('template')
  template.innerHTML = `
  <style>
      #chart {
          width: 100%;
          height: 100%;
      }
  </style>
  <div id="root" style="width: 100%; height: 100%;">
      <div id="chart"></div>
  </div>
  `

  /* ─────────────────────────────────────────────
   *  Main custom element  (unchanged)
   * ───────────────────────────────────────────── */
  class Main extends HTMLElement {
    constructor () {
      super()
      this._shadowRoot = this.attachShadow({ mode: 'open' })
      this._shadowRoot.appendChild(template.content.cloneNode(true))
      this._root     = this._shadowRoot.getElementById('root')
      this._props    = {}
      this._renderer = new Renderer(this._root)
    }

    async onCustomWidgetBeforeUpdate (changedProps) {
      this._props = { ...this._props, ...changedProps }
    }

    async onCustomWidgetAfterUpdate (changedProps) {
      this.render()
    }

    async onCustomWidgetResize (width, height) {
      this.render()
    }

    async onCustomWidgetDestroy () {
      this.dispose()
    }

    render () {
      if (!document.contains(this)) {
        setTimeout(this.render.bind(this), 0)
        return
      }
      this._renderer.render(this.dataBinding, this._props)
    }

    dispose () {
      this._renderer.dispose()
    }
  }

  customElements.define('com-sap-sac-sample-echarts-sankeyyg', Main)
})()
