/*
 * SAP Analytics Cloud - Custom Sankey Chart Widget
 * Version: 1.0.5
 *
 * Fixes & improvements:
 *   [FIX]  Linked analysis now works correctly in Optimized Story Experience
 *          — dataBindings accessed via this.dataBindings (not props['dataBindings'])
 *   [FIX]  Long node labels now wrap to two lines instead of overflowing
 *   [NEW]  Color palette selector — palette name stored in props, applied at render time
 *
 * Data binding setup in SAC Builder Panel:
 *   Dimensions feed : [0] Source dimension  (e.g. Client Domicile Country)
 *                     [1] Target dimension  (e.g. Financial Transaction Booking Country)
 *   Measures feed   : [0] Flow measure      (e.g. Amount / Transaction Value)
 */

var getScriptPromisify = (src) => {
  const __define = define
  define = undefined
  return new Promise(resolve => {
    $.getScript(src, () => {
      define = __define
      resolve()
    })
  })
}

;(function () {

  /* ─────────────────────────────────────────────
   *  Named color palettes
   *  Each palette has 20 distinct colors.
   *  Selected via props.colorPalette (set in styling panel).
   * ───────────────────────────────────────────── */
  const COLOR_PALETTES = {
    'Default': [
      '#5470C6','#91CC75','#FAC858','#EE6666','#73C0DE',
      '#3BA272','#FC8452','#9A60B4','#EA7CCC','#48B8D0',
      '#F4A261','#2A9D8F','#E76F51','#264653','#A8DADC',
      '#E9C46A','#457B9D','#E63946','#06D6A0','#FFB703'
    ],
    'Ocean': [
      '#03045E','#0077B6','#00B4D8','#90E0EF','#CAF0F8',
      '#023E8A','#0096C7','#48CAE4','#ADE8F4','#023E8A',
      '#2D6A4F','#40916C','#52B788','#74C69D','#95D5B2',
      '#1B4332','#2D6A4F','#40916C','#52B788','#74C69D'
    ],
    'Sunset': [
      '#FF6B35','#F7931E','#FFD700','#FF4E50','#FC913A',
      '#F9CA24','#F0932B','#EB4D4B','#6AB04C','#C7ECEE',
      '#E55039','#F39C12','#D35400','#C0392B','#E74C3C',
      '#FF7675','#FDCB6E','#E17055','#D63031','#FAB1A0'
    ],
    'Forest': [
      '#1B4332','#2D6A4F','#40916C','#52B788','#74C69D',
      '#95D5B2','#B7E4C7','#D8F3DC','#081C15','#1B4332',
      '#386641','#6A994E','#A7C957','#BC4749','#F2E8CF',
      '#3A5A40','#588157','#A3B18A','#DAD7CD','#344E41'
    ],
    'Corporate': [
      '#003366','#0066CC','#3399FF','#66B2FF','#99CCFF',
      '#CC0000','#FF3333','#FF6666','#FF9999','#FFCCCC',
      '#006600','#009900','#00CC00','#00FF00','#66FF66',
      '#663300','#994C00','#CC6600','#FF8000','#FFB366'
    ],
    'Pastel': [
      '#FFB3BA','#FFDFBA','#FFFFBA','#BAFFC9','#BAE1FF',
      '#FF9AA2','#FFB7B2','#FFDAC1','#E2F0CB','#B5EAD7',
      '#C7CEEA','#F8B4D9','#FAD7A0','#A9DFBF','#AED6F1',
      '#F9E79F','#D2B4DE','#A3E4D7','#FAD7A0','#F1948A'
    ]
  }

  const DEFAULT_PALETTE = 'Default'

  /* ─────────────────────────────────────────────
   *  Format a number as readable amount string
   * ───────────────────────────────────────────── */
  const formatAmount = (val) => {
    if (val == null) return ''
    if (Math.abs(val) >= 1e9) return (val / 1e9).toFixed(2) + 'B'
    if (Math.abs(val) >= 1e6) return (val / 1e6).toFixed(2) + 'M'
    if (Math.abs(val) >= 1e3) return (val / 1e3).toFixed(1) + 'K'
    return val.toLocaleString(undefined, { maximumFractionDigits: 2 })
  }

  /* ─────────────────────────────────────────────
   *  Wrap a long label to two lines
   *  Splits at the nearest word boundary before maxLen chars
   * ───────────────────────────────────────────── */
  const wrapLabel = (label, maxLen) => {
    if (!label || label.length <= maxLen) { return label }
    // Find last space before maxLen
    const cutAt = label.lastIndexOf(' ', maxLen)
    if (cutAt <= 0) {
      // No space found — hard cut
      return label.substring(0, maxLen) + '\n' + label.substring(maxLen)
    }
    return label.substring(0, cutAt) + '\n' + label.substring(cutAt + 1)
  }

  /* ─────────────────────────────────────────────
   *  Metadata parser
   * ───────────────────────────────────────────── */
  const parseMetadata = metadata => {
    const { dimensions: dimensionsMap, mainStructureMembers: measuresMap } = metadata
    const dimensions = []
    for (const key in dimensionsMap) {
      dimensions.push({ key, ...dimensionsMap[key] })
    }
    const measures = []
    for (const key in measuresMap) {
      measures.push({ key, ...measuresMap[key] })
    }
    return { dimensions, measures, dimensionsMap, measuresMap }
  }

  /* ─────────────────────────────────────────────
   *  Original hierarchy helper (single-dim fallback)
   * ───────────────────────────────────────────── */
  const appendTotal = (data) => {
    data = JSON.parse(JSON.stringify(data))
    const superRoot = {
      dimensions_0: { id: 'total', label: 'Total' },
      measures_0:   { raw: 0 }
    }
    data.forEach(d => {
      if (d.dimensions_0.parentId) { return }
      d.dimensions_0.parentId = 'total'
      superRoot.measures_0.raw += d.measures_0.raw
    })
    return [superRoot].concat(data)
  }

  /* ─────────────────────────────────────────────
   *  Build nodes + links from two dimensions
   * ───────────────────────────────────────────── */
  const buildDimToDimChart = (data, sourceDimKey, targetDimKey, measureKey, palette) => {
    const colors        = COLOR_PALETTES[palette] || COLOR_PALETTES[DEFAULT_PALETTE]
    const sourceNodeSet = new Map()
    const targetNodeSet = new Map()
    const linkMap       = new Map()
    const nodeValueMap  = new Map()
    let   grandTotal    = 0

    /* ── Pass 1: aggregate links + per-node totals ── */
    data.forEach(row => {
      const sourceLabel = row[sourceDimKey] && row[sourceDimKey].label
      const targetLabel = row[targetDimKey] && row[targetDimKey].label
      const value       = row[measureKey]   && row[measureKey].raw
      if (!sourceLabel || !targetLabel || !value) { return }

      const srcName = 'SRC_' + sourceLabel
      const tgtName = 'TGT_' + targetLabel

      nodeValueMap.set(srcName, (nodeValueMap.get(srcName) || 0) + value)
      nodeValueMap.set(tgtName, (nodeValueMap.get(tgtName) || 0) + value)
      grandTotal += value

      const linkKey = srcName + '||' + tgtName
      const existing = linkMap.get(linkKey)
      if (existing) {
        existing.value += value
      } else {
        linkMap.set(linkKey, { source: srcName, target: tgtName, value })
      }
    })

    /* ── Pass 2: build node objects ── */
    let colorIndex = 0
    nodeValueMap.forEach((nodeTotal, nodeName) => {
      const isSource   = nodeName.startsWith('SRC_')
      const cleanLabel = nodeName.replace(/^SRC_/, '').replace(/^TGT_/, '')
      const pct        = grandTotal > 0
        ? ((nodeTotal / grandTotal) * 100).toFixed(1)
        : '0.0'
      const color      = colors[colorIndex % colors.length]
      colorIndex++

      // Wrap long labels to two lines (max 14 chars per line)
      const wrappedLabel = wrapLabel(cleanLabel, 14)
      const displayLabel = wrappedLabel + '\n' + pct + '%'

      const nodeObj = {
        name:      nodeName,
        depth:     isSource ? 0 : 1,
        itemStyle: { color },
        label: {
          position:  isSource ? 'left' : 'right',
          formatter: () => displayLabel,
          fontSize:  11,
          lineHeight: 16,
          color:     '#333',
          overflow:  'break'
        }
      }

      if (isSource) sourceNodeSet.set(nodeName, nodeObj)
      else          targetNodeSet.set(nodeName, nodeObj)
    })

    const nodes = [...sourceNodeSet.values(), ...targetNodeSet.values()]
    const links = [...linkMap.values()]
    return { nodes, links, grandTotal }
  }

  /* ─────────────────────────────────────────────
   *  Renderer
   * ───────────────────────────────────────────── */
  class Renderer {
    constructor (root) {
      this._root   = root
      this._echart = null
    }

    async render (dataBinding, props, widgetState, widgetElement) {
      await getScriptPromisify('https://cdnjs.cloudflare.com/ajax/libs/echarts/5.0.0/echarts.min.js')
      this.dispose()

      if (dataBinding.state !== 'success') { return }

      const { data, metadata } = dataBinding
      const { dimensions, measures } = parseMetadata(metadata)
      const [measure] = measures
      const isDimToDim = dimensions.length >= 2

      // Active color palette from props
      const palette = (props.colorPalette && COLOR_PALETTES[props.colorPalette])
        ? props.colorPalette
        : DEFAULT_PALETTE

      let nodes, links, grandTotal

      if (isDimToDim) {
        const sourceDim = dimensions[0]
        const targetDim = dimensions[1]
        let workData    = data

        /* ── Apply rankBy filter ── */
        if (widgetState.rankTopN > 0) {
          const pairTotals = new Map()
          workData.forEach(row => {
            const srcLabel = row[sourceDim.key] && row[sourceDim.key].label
            const tgtLabel = row[targetDim.key] && row[targetDim.key].label
            const val      = row[measure.key]   && row[measure.key].raw
            if (!srcLabel || !tgtLabel || !val) return
            const key = srcLabel + '||' + tgtLabel
            pairTotals.set(key, (pairTotals.get(key) || 0) + val)
          })
          const sorted = [...pairTotals.entries()].sort((a, b) =>
            widgetState.rankOrder === 'bottom' ? a[1] - b[1] : b[1] - a[1]
          )
          const keepPairs = new Set(
            sorted.slice(0, widgetState.rankTopN).map(e => e[0])
          )
          workData = workData.filter(row => {
            const srcLabel = row[sourceDim.key] && row[sourceDim.key].label
            const tgtLabel = row[targetDim.key] && row[targetDim.key].label
            if (!srcLabel || !tgtLabel) return false
            return keepPairs.has(srcLabel + '||' + tgtLabel)
          })
        }

        /* ── Apply sortByValue ── */
        if (widgetState.sortOrder) {
          workData = [...workData].sort((a, b) => {
            const valA = (a[measure.key] && a[measure.key].raw) || 0
            const valB = (b[measure.key] && b[measure.key].raw) || 0
            return widgetState.sortOrder === 'ascending' ? valA - valB : valB - valA
          })
        }

        ;({ nodes, links, grandTotal } = buildDimToDimChart(
          workData,
          sourceDim.key,
          targetDim.key,
          measure.key,
          palette
        ))
      } else {
        const [dimension] = dimensions
        nodes      = []
        links      = []
        grandTotal = 0
        const augmented = appendTotal(data)
        augmented.forEach(d => {
          const { label, parentId } = d[dimension.key]
          const { raw } = d[measure.key]
          grandTotal += raw || 0
          nodes.push({ name: label })
          const dParent = augmented.find(p => p[dimension.key].id === parentId)
          if (dParent) {
            links.push({ source: dParent[dimension.key].label, target: label, value: raw })
          }
        })
      }

      const sourceDimDesc = isDimToDim ? (dimensions[0].description || 'Source') : 'Hierarchy'
      const targetDimDesc = isDimToDim ? (dimensions[1].description || 'Target') : ''
      const measureDesc   = measure.label || measure.description || 'Amount'

      let titleSuffix = ''
      if (widgetState.rankTopN > 0) {
        titleSuffix = ` — Top ${widgetState.rankTopN}${widgetState.rankOrder === 'bottom' ? ' (Bottom)' : ''} Flows`
      } else if (widgetState.sortOrder) {
        titleSuffix = widgetState.sortOrder === 'ascending' ? ' ↑' : ' ↓'
      }

      this._echart = echarts.init(this._root)

      this._echart.setOption({
        title: [
          {
            text:      measureDesc + ' Flow Analysis' + titleSuffix,
            left:      'center',
            top:       4,
            textStyle: { fontSize: 14, fontWeight: 'bold', color: '#333' }
          },
          {
            text:      sourceDimDesc,
            left:      '22%',   // aligned to chart series left boundary
            top:       28,
            textStyle: { fontSize: 11, color: '#888', fontWeight: 'normal' }
          },
          {
            text:      targetDimDesc,
            right:     '22%',   // aligned to chart series right boundary
            top:       28,
            textStyle: { fontSize: 11, color: '#888', fontWeight: 'normal' }
          },
          {
            text:      'Total: ' + formatAmount(grandTotal),
            left:      'center',
            bottom:    4,
            textStyle: { fontSize: 11, fontWeight: 'bold', color: '#555' }
          }
        ],

        tooltip: {
          trigger:   'item',
          triggerOn: 'mousemove',
          formatter: (params) => {
            if (params.dataType === 'edge') {
              const src = params.data.source.replace(/^SRC_/, '')
              const tgt = params.data.target.replace(/^TGT_/, '')
              const val = params.data.value
              const pct = grandTotal > 0
                ? ((val / grandTotal) * 100).toFixed(1) : '0.0'
              return [
                `<b>${src}</b> → <b>${tgt}</b>`,
                `Amount: <b>${formatAmount(val)}</b>`,
                `Share: <b>${pct}%</b> of total`
              ].join('<br/>')
            }
            if (params.dataType === 'node') {
              const cleanName = (params.data.name || '')
                .replace(/^SRC_/, '').replace(/^TGT_/, '')
              const isSource  = (params.data.name || '').startsWith('SRC_')
              return `<b>${cleanName}</b><br/><span style="color:#888">${isSource ? sourceDimDesc : targetDimDesc}</span>`
            }
            return params.name
          }
        },

        series: [{
          type:      'sankey',
          top:       55,
          bottom:    25,
          left:      '22%',   // wide left margin so source labels never get clipped
          right:     '22%',   // equal right margin keeps chart centred
          data:      nodes,
          links:     links,
          emphasis:  { focus: 'adjacency' },
          silent:    !widgetState.enabled,
          nodeWidth: 20,
          nodeGap:   12,
          label: {
            show:       true,
            fontSize:   11,
            lineHeight: 16,
            formatter:  (params) => {
              const clean = (params.name || '')
                .replace(/^SRC_/, '').replace(/^TGT_/, '')
              return wrapLabel(clean, 14)
            }
          },
          levels: [
            { depth: 0, lineStyle: { color: 'source', opacity: props.depth0Settings.lineOpacity } },
            { depth: 1, lineStyle: { color: 'source', opacity: props.depth1Settings.lineOpacity } },
            { depth: 2, lineStyle: { color: 'source', opacity: props.depth2Settings.lineOpacity } },
            { depth: 3, lineStyle: { color: 'source', opacity: props.depth3Settings.lineOpacity } }
          ],
          lineStyle: { curveness: 0.7 }
        }]
      })

      /* ── Context menu ── */
      this._removeContextMenuEl()
      if (widgetState.contextMenuVisible) {
        this._contextMenuHandler = this._onContextMenu.bind(
          this, props, widgetState, widgetElement
        )
        this._root.addEventListener('contextmenu', this._contextMenuHandler)
      }

      /* ── Click handler — FIXED for Optimized Story Experience ──
       *
       *  KEY FIX: In Optimized Story Experience, getLinkedAnalysis() must be
       *  accessed via widgetElement.dataBindings (the custom element's own
       *  dataBindings property), NOT via props['dataBindings'].
       *  props['dataBindings'] works in Analytics Designer only.
       * ────────────────────────────────────────────────────────── */
      if (widgetState.enabled) {
        this._echart.on('click', (params) => {
          // Track selection for getSelections()
          widgetState.currentSelection = params

          // ✅ Correct API for Optimized Story Experience
          const linkedAnalysis = widgetElement.dataBindings
            .getDataBinding('dataBinding')
            .getLinkedAnalysis()

          if (isDimToDim) {
            const sourceDim = dimensions[0]
            const targetDim = dimensions[1]

            if (params.dataType === 'node') {
              /* Node click → filter one dimension */
              const rawName   = (params.data.name || '')
              const isSource  = rawName.startsWith('SRC_')
              const cleanName = rawName.replace(/^SRC_/, '').replace(/^TGT_/, '')
              const dim       = isSource ? sourceDim : targetDim

              const hit = dataBinding.data.find(
                row => row[dim.key] && row[dim.key].label === cleanName
              )
              if (hit) {
                const selection = {}
                selection[dim.id] = hit[dim.key].id
                linkedAnalysis.setFilters(selection)
              } else {
                linkedAnalysis.removeFilters()
              }

            } else if (params.dataType === 'edge') {
              /* Edge click → filter both dimensions */
              const srcName = (params.data.source || '').replace(/^SRC_/, '')
              const tgtName = (params.data.target || '').replace(/^TGT_/, '')

              const srcRow = dataBinding.data.find(
                row => row[sourceDim.key] && row[sourceDim.key].label === srcName
              )
              const tgtRow = dataBinding.data.find(
                row => row[targetDim.key] && row[targetDim.key].label === tgtName
              )

              if (srcRow && tgtRow) {
                const selection = {}
                selection[sourceDim.id] = srcRow[sourceDim.key].id
                selection[targetDim.id] = tgtRow[targetDim.key].id
                linkedAnalysis.setFilters(selection)
              } else {
                linkedAnalysis.removeFilters()
              }

            } else {
              linkedAnalysis.removeFilters()
            }

          } else {
            /* Single-dimension fallback */
            const [dimension] = dimensions
            const label = params.dataType === 'node'
              ? params.data.name
              : params.dataType === 'edge' ? params.data.target : ''
            const selectedItem = dataBinding.data.find(
              item => item[dimension.key] && item[dimension.key].label === label
            )
            if (selectedItem) {
              const selection = {}
              selection[dimension.id] = selectedItem[dimension.key].id
              linkedAnalysis.setFilters(selection)
            } else {
              linkedAnalysis.removeFilters()
            }
          }
        })
      }
    }

    /* ── Context menu ── */
    _onContextMenu (props, widgetState, widgetElement, event) {
      event.preventDefault()
      this._removeContextMenuEl()

      const menu = document.createElement('div')
      menu.id = '__sankeyContextMenu'
      menu.style.cssText = `
        position:fixed; z-index:9999; background:#fff; border:1px solid #ddd;
        border-radius:6px; box-shadow:0 4px 16px rgba(0,0,0,0.15);
        font-family:sans-serif; font-size:13px; min-width:190px; overflow:hidden;
      `
      menu.style.left = event.clientX + 'px'
      menu.style.top  = event.clientY + 'px'

      const items = [
        { label: '↓ Sort: High → Low', action: () => { widgetState.sortOrder = 'descending'; widgetState.rankTopN = 0; widgetElement.render() } },
        { label: '↑ Sort: Low → High', action: () => { widgetState.sortOrder = 'ascending';  widgetState.rankTopN = 0; widgetElement.render() } },
        { label: '✕ Clear Sort / Rank',  action: () => { widgetState.sortOrder = null; widgetState.rankTopN = 0; widgetElement.render() } },
        { label: '🏆 Show Top 5 Flows',  action: () => { widgetState.rankTopN = 5;  widgetState.rankOrder = 'top'; widgetState.sortOrder = null; widgetElement.render() } },
        { label: '🏆 Show Top 10 Flows', action: () => { widgetState.rankTopN = 10; widgetState.rankOrder = 'top'; widgetState.sortOrder = null; widgetElement.render() } },
      ]

      items.forEach((item, i) => {
        const el = document.createElement('div')
        el.textContent = item.label
        el.style.cssText = `padding:9px 16px; cursor:pointer;${i < items.length - 1 ? 'border-bottom:1px solid #f0f0f0;' : ''}`
        el.addEventListener('mouseenter', () => { el.style.background = '#f5f5f5' })
        el.addEventListener('mouseleave', () => { el.style.background = '' })
        el.addEventListener('click', () => { item.action(); this._removeContextMenuEl() })
        menu.appendChild(el)
      })

      document.body.appendChild(menu)
      setTimeout(() => {
        document.addEventListener('click', () => this._removeContextMenuEl(), { once: true })
      }, 0)
    }

    _removeContextMenuEl () {
      const el = document.getElementById('__sankeyContextMenu')
      if (el) el.remove()
    }

    dispose () {
      this._removeContextMenuEl()
      if (this._root && this._contextMenuHandler) {
        this._root.removeEventListener('contextmenu', this._contextMenuHandler)
      }
      if (this._echart) {
        echarts.dispose(this._echart)
      }
    }
  }

  /* ─────────────────────────────────────────────
   *  HTML Template
   * ───────────────────────────────────────────── */
  const template = document.createElement('template')
  template.innerHTML = `
  <style>
    #chart { width: 100%; height: 100%; }
  </style>
  <div id="root" style="width: 100%; height: 100%;">
    <div id="chart"></div>
  </div>
  `

  /* ─────────────────────────────────────────────
   *  Main Custom Element
   * ───────────────────────────────────────────── */
  class Main extends HTMLElement {
    constructor () {
      super()
      this._shadowRoot = this.attachShadow({ mode: 'open' })
      this._shadowRoot.appendChild(template.content.cloneNode(true))
      this._root     = this._shadowRoot.getElementById('root')
      this._props    = {}
      this._renderer = new Renderer(this._root)

      this._widgetState = {
        enabled:            true,
        contextMenuVisible: false,
        sortOrder:          null,
        rankTopN:           0,
        rankOrder:          'top',
        currentSelection:   null
      }
    }

    async onCustomWidgetBeforeUpdate (changedProps) {
      this._props = { ...this._props, ...changedProps }
    }

    async onCustomWidgetAfterUpdate (changedProps) {
      this.render()
    }

    async onCustomWidgetResize (width, height) {
      this.render()
    }

    async onCustomWidgetDestroy () {
      this.dispose()
    }

    render () {
      if (!document.contains(this)) {
        setTimeout(this.render.bind(this), 0)
        return
      }
      // Pass `this` (the custom element) to the renderer
      // so it can access this.dataBindings directly for linked analysis
      this._renderer.render(this.dataBinding, this._props, this._widgetState, this)
    }

    dispose () {
      this._renderer.dispose()
    }

    // ── CChart-style Script Methods ──

    async addDimension (dimensionId, feed) {
      await this.dataBindings.getDataBinding('dataBinding').addDimensionToFeed(feed, dimensionId)
    }

    async removeDimension (dimensionId, feed) {
      await this.dataBindings.getDataBinding('dataBinding').removeMember(feed, dimensionId)
    }

    async addMember (feed, memberId) {
      await this.dataBindings.getDataBinding('dataBinding').addMemberToFeed(feed, memberId)
    }

    async removeMember (feed, memberId) {
      await this.dataBindings.getDataBinding('dataBinding').removeMember(feed, memberId)
    }

    getDataSource () {
      return this.dataBindings.getDataBinding('dataBinding').getDataSource()
    }

    getSelections () {
      const s = this._widgetState.currentSelection
      if (!s) { return null }
      if (s.dataType === 'node') {
        return {
          dataType: 'node',
          name:     (s.data.name || '').replace(/^SRC_/, '').replace(/^TGT_/, ''),
          side:     (s.data.name || '').startsWith('SRC_') ? 'source' : 'target',
          rawName:  s.data.name
        }
      }
      if (s.dataType === 'edge') {
        return {
          dataType: 'edge',
          source:   (s.data.source || '').replace(/^SRC_/, ''),
          target:   (s.data.target || '').replace(/^TGT_/, ''),
          value:    s.data.value
        }
      }
      return null
    }

    sortByValue (sortOrder) {
      this._widgetState.sortOrder = sortOrder
      this._widgetState.rankTopN  = 0
      this.render()
    }

    removeSorting () {
      this._widgetState.sortOrder = null
      this.render()
    }

    rankBy (topN, rankOrder) {
      this._widgetState.rankTopN  = parseInt(topN, 10) || 5
      this._widgetState.rankOrder = rankOrder === 'bottom' ? 'bottom' : 'top'
      this._widgetState.sortOrder = null
      this.render()
    }

    removeRanking () {
      this._widgetState.rankTopN  = 0
      this._widgetState.rankOrder = 'top'
      this.render()
    }

    setEnabled (enabled) {
      this._widgetState.enabled = !!enabled
      this.render()
    }

    isEnabled () {
      return this._widgetState.enabled
    }

    setContextMenuVisible (visible) {
      this._widgetState.contextMenuVisible = !!visible
      this.render()
    }
  }

  customElements.define('com-sap-sac-sample-echarts-sankeyyg', Main)
})()
