var getScriptPromisify = (src) => {
  const __define = define
  define = undefined
  return new Promise(resolve => {
    $.getScript(src, () => {
      define = __define
      resolve()
    })
  })
}

(function () {

  const parseMetadata = metadata => {
    const { dimensions: dMap, mainStructureMembers: mMap } = metadata
    const dimensions = Object.keys(dMap).map(k => ({ key: k, ...dMap[k] }))
    const measures = Object.keys(mMap).map(k => ({ key: k, ...mMap[k] }))
    return { dimensions, measures }
  }

  class Renderer {

    constructor(root) {
      this._root = root
      this._echart = null
    }

    async render(dataBinding, props) {

      await getScriptPromisify(
        "https://cdnjs.cloudflare.com/ajax/libs/echarts/5.0.0/echarts.min.js"
      )

      this.dispose()

      if (dataBinding.state !== "success") return

      const { data, metadata } = dataBinding
      const { dimensions, measures } = parseMetadata(metadata)

      if (dimensions.length < 2) return

      const [dimSource, dimTarget] = dimensions
      const [measure] = measures

      const nodeIndex = {}
      const nodes = []
      const linksMap = {}

      data.forEach(row => {

        const source = row[dimSource.key]?.label
        const target = row[dimTarget.key]?.label
        const value = row[measure.key]?.raw || 0

        if (!source || !target || value === 0) return

        if (!nodeIndex[source]) {
          nodeIndex[source] = true
          nodes.push({ name: source, depth: 0 })
        }

        if (!nodeIndex[target]) {
          nodeIndex[target] = true
          nodes.push({ name: target, depth: 1 })
        }

        const key = source + "|" + target
        linksMap[key] ??= { source, target, value: 0 }
        linksMap[key].value += value
      })

      const links = Object.values(linksMap)

      this._echart = echarts.init(this._root)

      this._echart.setOption({
        tooltip: {
          trigger: "item",
          triggerOn: "mousemove"
        },
        series: [{
          type: "sankey",
          data: nodes,
          links: links,
          emphasis: { focus: "adjacency" },
          levels: [
            {
              depth: 0,
              itemStyle: { color: props.depth0Settings.itemColor },
              lineStyle: { color: "source", opacity: props.depth0Settings.lineOpacity }
            },
            {
              depth: 1,
              itemStyle: { color: props.depth1Settings.itemColor },
              lineStyle: { color: "source", opacity: props.depth1Settings.lineOpacity }
            }
          ],
          lineStyle: { curveness: 0.7 }
        }]
      })

      const linkedAnalysis =
        props.dataBindings.getDataBinding("dataBinding").getLinkedAnalysis()

      this._echart.on("click", params => {

        if (!linkedAnalysis) return

        const selection = {}
        const dimensionIds = dimensions.map(d => d.id)

        const match = data.find(r =>
          dimensions.some(d => r[d.key]?.label === params.data.name))

        if (!match) return

        dimensions.forEach((d, i) => {
          if (match[d.key]?.label === params.data.name)
            selection[dimensionIds[i]] = match[d.key].id
        })

        linkedAnalysis.setFilters(selection)
      })
    }

    dispose() {
      if (this._echart) echarts.dispose(this._echart)
    }
  }

  const template = document.createElement('template')
  template.innerHTML = `
  <style>
      #root { width:100%; height:100%; }
  </style>
  <div id="root"></div>
  `

  class Main extends HTMLElement {

    constructor () {
      super()
      this._shadowRoot = this.attachShadow({ mode: 'open' })
      this._shadowRoot.appendChild(template.content.cloneNode(true))
      this._root = this._shadowRoot.getElementById('root')
      this._props = {}
      this._renderer = new Renderer(this._root)
    }

    async onCustomWidgetBeforeUpdate(changedProps) {
      this._props = { ...this._props, ...changedProps }
    }

    async onCustomWidgetAfterUpdate() {
      this.render()
    }

    async onCustomWidgetResize() {
      this.render()
    }

    render() {
      this._renderer.render(this.dataBinding, this._props)
    }

    dispose() {
      this._renderer.dispose()
    }
  }

  customElements.define(
    'com-sap-sac-sample-echarts-sankeyyg',
    Main
  )

})()