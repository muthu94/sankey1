(function () {

  const template = document.createElement("template");

  template.innerHTML = `
    <style>
      .depthSettings { margin:8px 0 }
      label { width:110px; display:inline-block }
    </style>

    ${[0,1,2,3].map(d => `
      <div class="depthSettings">
        <b>Depth ${d}</b><br/>
        <label>Color</label>
        <input id="c${d}" type="text"/><br/>
        <label>Line Opacity</label>
        <input id="o${d}" type="number" step="0.1"/>
      </div>
    `).join("")}
  `;

  class SankeyChartStylingPanel extends HTMLElement {

    constructor() {
      super();

      this._props = {};
      this.attachShadow({ mode: "open" })
        .appendChild(template.content.cloneNode(true));

      [0,1,2,3].forEach(d => {
        this.shadowRoot.getElementById(`c${d}`)
          .addEventListener("change", () => this._notify(d));

        this.shadowRoot.getElementById(`o${d}`)
          .addEventListener("change", () => this._notify(d));
      });
    }

    onCustomWidgetBeforeUpdate(changedProps) {

      this._props = { ...this._props, ...changedProps };

      [0,1,2,3].forEach(d => {
        const key = `depth${d}Settings`;

        if (changedProps[key]) {
          this.shadowRoot.getElementById(`c${d}`).value =
            changedProps[key].itemColor || "";

          this.shadowRoot.getElementById(`o${d}`).value =
            changedProps[key].lineOpacity ?? "";
        }
      });
    }

    _notify(depth) {

      const properties = {};

      properties[`depth${depth}Settings`] = {
        itemColor: this.shadowRoot.getElementById(`c${depth}`).value,
        lineOpacity: parseFloat(
          this.shadowRoot.getElementById(`o${depth}`).value
        )
      };

      this.dispatchEvent(
        new CustomEvent("propertiesChanged", {
          detail: { properties }
        })
      );
    }
  }

  customElements.define(
    "com-sap-sac-sample-echarts-sankeyyg-styling",
    SankeyChartStylingPanel
  );

})();