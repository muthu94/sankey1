(function() {
    let template = document.createElement("template");
    template.innerHTML = `
      <style>
        .section {
          margin: 0.75rem 0;
        }
        .section-title {
          font-size: 12px;
          font-weight: 600;
          color: #333;
          margin-bottom: 0.4rem;
        }
        .depthSettings {
          margin: 0.5rem 0;
        }
        .depth {
          font-size: 14px;
          font-weight: 500;
        }
        .settings {
          color: #666;
          font-size: 13px;
        }
        .settings label {
          display: inline-block;
          line-height: 1.75rem;
          width: 5.625rem;
        }
        .settings input {
          color: #333;
          line-height: 1.25rem;
        }
        .palette-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 6px;
          margin-top: 4px;
        }
        .palette-btn {
          border: 2px solid transparent;
          border-radius: 5px;
          cursor: pointer;
          padding: 4px 3px 3px 3px;
          background: #f8f8f8;
          text-align: center;
          font-size: 10px;
          color: #444;
          transition: border-color 0.15s;
        }
        .palette-btn:hover {
          border-color: #aaa;
        }
        .palette-btn.selected {
          border-color: #0070f3;
          background: #e8f0fe;
        }
        .palette-swatches {
          display: flex;
          gap: 2px;
          justify-content: center;
          margin-bottom: 3px;
        }
        .swatch {
          width: 10px;
          height: 10px;
          border-radius: 2px;
        }
        .divider {
          border: none;
          border-top: 1px solid #eee;
          margin: 0.75rem 0;
        }
      </style>

      <div>

        <!-- ── Color Palette Selector ── -->
        <div class="section">
          <div class="section-title">Color Palette</div>
          <div class="palette-grid" id="paletteGrid">
            <!-- Populated by JS -->
          </div>
        </div>

        <hr class="divider"/>

        <!-- ── Depth opacity settings ── -->
        <div class="section">
          <div class="section-title">Flow Line Opacity</div>

          <div class="depthSettings">
            <div class="depth"><label>Depth 0</label></div>
            <div class="settings">
              <div><label>Color:</label><input id="depth0_itemColor" type="text" name="color" /></div>
              <div><label>Opacity:</label><input id="depth0_lineOpacity" type="text" name="opacity" /></div>
            </div>
          </div>

          <div class="depthSettings">
            <div class="depth"><label>Depth 1</label></div>
            <div class="settings">
              <div><label>Color:</label><input id="depth1_itemColor" type="text" name="color" /></div>
              <div><label>Opacity:</label><input id="depth1_lineOpacity" type="text" name="opacity" /></div>
            </div>
          </div>

          <div class="depthSettings">
            <div class="depth"><label>Depth 2</label></div>
            <div class="settings">
              <div><label>Color:</label><input id="depth2_itemColor" type="text" name="color" /></div>
              <div><label>Opacity:</label><input id="depth2_lineOpacity" type="text" name="opacity" /></div>
            </div>
          </div>

          <div class="depthSettings">
            <div class="depth"><label>Depth 3</label></div>
            <div class="settings">
              <div><label>Color:</label><input id="depth3_itemColor" type="text" name="color" /></div>
              <div><label>Opacity:</label><input id="depth3_lineOpacity" type="text" name="opacity" /></div>
            </div>
          </div>
        </div>

      </div>
    `;

    /* ── Palette definitions (first 5 swatches shown as preview) ── */
    const PALETTES = {
      'Default':   ['#5470C6','#91CC75','#FAC858','#EE6666','#73C0DE'],
      'Ocean':     ['#03045E','#0077B6','#00B4D8','#90E0EF','#2D6A4F'],
      'Sunset':    ['#FF6B35','#F7931E','#FFD700','#FF4E50','#FC913A'],
      'Forest':    ['#1B4332','#2D6A4F','#40916C','#52B788','#74C69D'],
      'Corporate': ['#003366','#0066CC','#CC0000','#006600','#663300'],
      'Pastel':    ['#FFB3BA','#FFDFBA','#FFFFBA','#BAFFC9','#BAE1FF']
    }

    class SankeyChartStylingPanel extends HTMLElement {
        constructor() {
            super();
            this._shadowRoot = this.attachShadow({mode: "open"});
            this._shadowRoot.appendChild(template.content.cloneNode(true));

            this._props = {};
            this._selectedPalette = 'Default';

            // Build palette grid
            this._buildPaletteGrid();

            // Wire depth setting change listeners
            this._shadowRoot.getElementById("depth0_itemColor").addEventListener("change", this.onDepthSettingsChanged.bind(this, 0));
            this._shadowRoot.getElementById("depth0_lineOpacity").addEventListener("change", this.onDepthSettingsChanged.bind(this, 0));
            this._shadowRoot.getElementById("depth1_itemColor").addEventListener("change", this.onDepthSettingsChanged.bind(this, 1));
            this._shadowRoot.getElementById("depth1_lineOpacity").addEventListener("change", this.onDepthSettingsChanged.bind(this, 1));
            this._shadowRoot.getElementById("depth2_itemColor").addEventListener("change", this.onDepthSettingsChanged.bind(this, 2));
            this._shadowRoot.getElementById("depth2_lineOpacity").addEventListener("change", this.onDepthSettingsChanged.bind(this, 2));
            this._shadowRoot.getElementById("depth3_itemColor").addEventListener("change", this.onDepthSettingsChanged.bind(this, 3));
            this._shadowRoot.getElementById("depth3_lineOpacity").addEventListener("change", this.onDepthSettingsChanged.bind(this, 3));
        }

        /* ── Build the palette button grid ── */
        _buildPaletteGrid() {
            const grid = this._shadowRoot.getElementById('paletteGrid');
            grid.innerHTML = '';

            Object.entries(PALETTES).forEach(([name, swatches]) => {
                const btn = document.createElement('div');
                btn.className = 'palette-btn' + (name === this._selectedPalette ? ' selected' : '');
                btn.dataset.palette = name;

                // Swatch row
                const swatchRow = document.createElement('div');
                swatchRow.className = 'palette-swatches';
                swatches.forEach(color => {
                    const s = document.createElement('div');
                    s.className = 'swatch';
                    s.style.background = color;
                    swatchRow.appendChild(s);
                });

                // Label
                const label = document.createElement('div');
                label.textContent = name;

                btn.appendChild(swatchRow);
                btn.appendChild(label);

                btn.addEventListener('click', () => this._onPaletteSelected(name));
                grid.appendChild(btn);
            });
        }

        /* ── Handle palette button click ── */
        _onPaletteSelected(paletteName) {
            this._selectedPalette = paletteName;

            // Update selected state visually
            this._shadowRoot.querySelectorAll('.palette-btn').forEach(btn => {
                btn.classList.toggle('selected', btn.dataset.palette === paletteName);
            });

            // Dispatch propertiesChanged to notify SAC → triggers chart re-render
            this.dispatchEvent(new CustomEvent("propertiesChanged", {
                detail: {
                    properties: {
                        colorPalette: paletteName
                    }
                }
            }));
        }

        connectedCallback() {}
        disconnectedCallback() {}

        onCustomWidgetBeforeUpdate(changedProps) {
            this._props = { ...this._props, ...changedProps };

            // Sync palette selection if changed externally (e.g. bookmark restore)
            if ("colorPalette" in changedProps && changedProps["colorPalette"]) {
                this._selectedPalette = changedProps["colorPalette"];
                this._buildPaletteGrid();
            }

            if ("depth0Settings" in changedProps) this.updateDepthSettings(changedProps["depth0Settings"], 0);
            if ("depth1Settings" in changedProps) this.updateDepthSettings(changedProps["depth1Settings"], 1);
            if ("depth2Settings" in changedProps) this.updateDepthSettings(changedProps["depth2Settings"], 2);
            if ("depth3Settings" in changedProps) this.updateDepthSettings(changedProps["depth3Settings"], 3);
        }

        onCustomWidgetAfterUpdate(changedProps) {}
        onCustomWidgetDestroy() {}

        updateDepthSettings(settings, depth) {
            this[`depth${depth}Color`]   = settings.itemColor;
            this[`depth${depth}Opacity`] = settings.lineOpacity;
        }

        onDepthSettingsChanged(depth, event) {
            event.preventDefault();
            const properties = {};
            properties[`depth${depth}Settings`] = {
                itemColor:   this[`depth${depth}Color`],
                lineOpacity: this[`depth${depth}Opacity`]
            };
            this.dispatchEvent(new CustomEvent("propertiesChanged", {
                detail: { properties }
            }));
        }

        set depth0Color(value)   { this._shadowRoot.getElementById("depth0_itemColor").value = value; }
        get depth0Color()        { return this._shadowRoot.getElementById("depth0_itemColor").value; }
        set depth0Opacity(value) { this._shadowRoot.getElementById("depth0_lineOpacity").value = value; }
        get depth0Opacity()      { return parseFloat(this._shadowRoot.getElementById("depth0_lineOpacity").value); }

        set depth1Color(value)   { this._shadowRoot.getElementById("depth1_itemColor").value = value; }
        get depth1Color()        { return this._shadowRoot.getElementById("depth1_itemColor").value; }
        set depth1Opacity(value) { this._shadowRoot.getElementById("depth1_lineOpacity").value = value; }
        get depth1Opacity()      { return parseFloat(this._shadowRoot.getElementById("depth1_lineOpacity").value); }

        set depth2Color(value)   { this._shadowRoot.getElementById("depth2_itemColor").value = value; }
        get depth2Color()        { return this._shadowRoot.getElementById("depth2_itemColor").value; }
        set depth2Opacity(value) { this._shadowRoot.getElementById("depth2_lineOpacity").value = value; }
        get depth2Opacity()      { return parseFloat(this._shadowRoot.getElementById("depth2_lineOpacity").value); }

        set depth3Color(value)   { this._shadowRoot.getElementById("depth3_itemColor").value = value; }
        get depth3Color()        { return this._shadowRoot.getElementById("depth3_itemColor").value; }
        set depth3Opacity(value) { this._shadowRoot.getElementById("depth3_lineOpacity").value = value; }
        get depth3Opacity()      { return parseFloat(this._shadowRoot.getElementById("depth3_lineOpacity").value); }
    }

    customElements.define("com-sap-sac-sample-echarts-sankeyyg-styling", SankeyChartStylingPanel);
})();
