// Styling panel (unchanged from your original implementation)
(function() {
  class SankeyChartStylingPanel extends HTMLElement {
    constructor() {
      super();
      const shadow = this.attachShadow({mode: "open"});
      shadow.innerHTML = `<div>Styling Panel Active</div>`;
    }
  }
  customElements.define(
    "com-sap-sac-sample-echarts-sankeyyg-styling",
    SankeyChartStylingPanel
  );
})();
