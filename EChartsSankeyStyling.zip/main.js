
var getScriptPromisify = (src) => {
  const __define = define
  define = undefined
  return new Promise(resolve => {
    $.getScript(src, () => {
      define = __define
      resolve()
    })
  })
}

(function () {

  const parseMetadata = metadata => {
    const { dimensions: dMap, mainStructureMembers: mMap } = metadata
    const dimensions = Object.keys(dMap).map(k => ({ key: k, ...dMap[k] }))
    const measures = Object.keys(mMap).map(k => ({ key: k, ...mMap[k] }))
    return { dimensions, measures }
  }

  class Renderer {

    constructor(root) {
      this._root = root
      this._echart = null
    }

    async render(dataBinding, props) {

      await getScriptPromisify(
        "https://cdnjs.cloudflare.com/ajax/libs/echarts/5.0.0/echarts.min.js"
      )

      if (dataBinding.state !== "success") return

      const { data, metadata } = dataBinding
      const { dimensions, measures } = parseMetadata(metadata)

      const [measure] = measures

      const nodes = []
      const links = []

      let sankeyOrient =
        dimensions.length === 1 ? "vertical" : "horizontal"

      if (dimensions.length >= 2) {

        const [dimSource, dimTarget] = dimensions

        const nodeIndex = Object.create(null)
        const linkMap = Object.create(null)

        let nodeCounter = 0

        for (let i = 0; i < data.length; i++) {

          const row = data[i]

          const source = row[dimSource.key]?.label
          const target = row[dimTarget.key]?.label
          const value = row[measure.key]?.raw || 0

          if (!source || !target || value === 0) continue

          if (nodeIndex[source] === undefined) {
            nodeIndex[source] = nodeCounter++
            nodes.push({ name: source, depth: 0 })
          }

          if (nodeIndex[target] === undefined) {
            nodeIndex[target] = nodeCounter++
            nodes.push({ name: target, depth: 1 })
          }

          const key = source + "|" + target

          if (!linkMap[key]) {
            linkMap[key] = { source, target, value: 0 }
          }

          linkMap[key].value += value
        }

        let aggregatedLinks = Object.values(linkMap)

        aggregatedLinks.sort((a, b) => b.value - a.value)

        aggregatedLinks.slice(0, 1500)
          .forEach(l => links.push(l))
      }

      let totalFlow = 0
      const nodeStats = {}

      links.forEach(l => {

        totalFlow += l.value

        nodeStats[l.source] ??= { in: 0, out: 0 }
        nodeStats[l.target] ??= { in: 0, out: 0 }

        nodeStats[l.source].out += l.value
        nodeStats[l.target].in += l.value
      })

      const ranked = [...links].sort((a, b) => b.value - a.value)
      const linkRank = {}
      ranked.forEach((l, i) =>
        linkRank[l.source + "|" + l.target] = i + 1)

      const formatNumber = v =>
        v.toLocaleString(undefined, { maximumFractionDigits: 2 })

      this._echart = echarts.init(this._root)

      this._echart.setOption({

        tooltip: {
          trigger: "item",
          formatter: (params) => {

            if (params.dataType === "edge") {

              const { source, target, value } = params.data
              const percent = totalFlow
                ? ((value / totalFlow) * 100).toFixed(2)
                : 0

              return `
              <b>${source} → ${target}</b><br/>
              Amount: ${formatNumber(value)}<br/>
              Share: ${percent}%<br/>
              Rank: #${linkRank[source+"|"+target]}
              `
            }

            if (params.dataType === "node") {

              const stats = nodeStats[params.data.name]
                || { in: 0, out: 0 }

              const net = stats.out - stats.in

              return `
              <b>${params.data.name}</b><br/>
              Outflow: ${formatNumber(stats.out)}<br/>
              Inflow: ${formatNumber(stats.in)}<br/>
              Net: ${formatNumber(net)}
              `
            }
          }
        },

        series: [{
          type: "sankey",
          orient: sankeyOrient,
          data: nodes,
          links: links,
          animation: false,
          progressive: 2000,
          progressiveThreshold: 3000,
          nodeAlign: "justify",
          nodeGap: 12,
          nodeWidth: 18,
          emphasis: { focus: "adjacency" },
          lineStyle: {
            color: "source",
            curveness: 0.7
          }
        }]
      })

      const linkedAnalysis =
        props.dataBindings
          .getDataBinding("dataBinding")
          .getLinkedAnalysis()

      const dimensionIds = dimensions.map(d => d.id)
      const dimensionKeys = dimensions.map(d => d.key)

      this._echart.on("click", params => {

        if (!linkedAnalysis) return

        const selection = {}

        if (params.dataType === "edge") {

          const { source, target } = params.data

          const match = data.find(r =>
            r[dimensionKeys[0]]?.label === source &&
            r[dimensionKeys[1]]?.label === target)

          if (!match) return

          dimensionKeys.forEach((k, i) =>
            selection[dimensionIds[i]] = match[k].id)

          linkedAnalysis.setFilters(selection)
        }

        else if (params.dataType === "node") {

          const name = params.data.name

          const match = data.find(r =>
            dimensionKeys.some(k => r[k]?.label === name))

          if (!match) return

          dimensionKeys.forEach((k, i) => {
            if (match[k]?.label === name)
              selection[dimensionIds[i]] = match[k].id
          })

          linkedAnalysis.setFilters(selection)
        }
      })
    }

    dispose() {
      if (this._echart) echarts.dispose(this._echart)
    }
  }

  const template = document.createElement("template")
  template.innerHTML = `<div id="root" style="width:100%;height:100%"></div>`

  class Main extends HTMLElement {

    constructor() {
      super()
      this.attachShadow({ mode: "open" })
        .appendChild(template.content.cloneNode(true))

      this._renderer =
        new Renderer(this.shadowRoot.getElementById("root"))
    }

    onCustomWidgetAfterUpdate() {
      this._renderer.render(this.dataBinding, this)
    }

    onCustomWidgetDestroy() {
      this._renderer.dispose()
    }
  }

  customElements.define(
    "com-sap-sac-sample-echarts-sankeyyg",
    Main
  )
})()
