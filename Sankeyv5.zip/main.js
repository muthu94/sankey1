/*
 * SAP Analytics Cloud - Custom Sankey Chart Widget
 * Version: 1.0.3
 *
 * Improvements in this version:
 *   - Auto-assigned distinct colors per node (source + target)
 *   - Node labels: both sides (source=left, target=right) + country name + % of total
 *   - Tooltip: Source → Target + Amount + % of total
 *   - Chart title, column headers (source/target), total amount legend
 *   - Linked analysis: node click filters one dimension; edge click filters both
 *   - Performance: aggregation + null/zero handling retained
 *
 * Data binding setup in SAC Builder Panel:
 *   Dimensions feed : [0] Source dimension  (e.g. Client Domicile Country)
 *                     [1] Target dimension  (e.g. Financial Transaction Booking Country)
 *   Measures feed   : [0] Flow measure      (e.g. Amount / Transaction Value)
 */

var getScriptPromisify = (src) => {
  // Workaround for conflict between geo widget and echarts.
  const __define = define
  define = undefined
  return new Promise(resolve => {
    $.getScript(src, () => {
      define = __define
      resolve()
    })
  })
}

;(function () {

  /* ─────────────────────────────────────────────
   *  Distinct color palette — auto-assigned per node
   *  20 visually distinct colors, cycles if more nodes
   * ───────────────────────────────────────────── */
  const NODE_COLORS = [
    '#5470C6', '#91CC75', '#FAC858', '#EE6666', '#73C0DE',
    '#3BA272', '#FC8452', '#9A60B4', '#EA7CCC', '#48B8D0',
    '#F4A261', '#2A9D8F', '#E76F51', '#264653', '#A8DADC',
    '#E9C46A', '#457B9D', '#E63946', '#06D6A0', '#FFB703'
  ]

  /* ─────────────────────────────────────────────
   *  Format a number as a readable amount string
   *  e.g. 4200000 → "4.20M"  |  850000 → "850.0K"
   * ───────────────────────────────────────────── */
  const formatAmount = (val) => {
    if (val == null) return ''
    if (Math.abs(val) >= 1e9) return (val / 1e9).toFixed(2) + 'B'
    if (Math.abs(val) >= 1e6) return (val / 1e6).toFixed(2) + 'M'
    if (Math.abs(val) >= 1e3) return (val / 1e3).toFixed(1) + 'K'
    return val.toLocaleString(undefined, { maximumFractionDigits: 2 })
  }

  /* ─────────────────────────────────────────────
   *  Metadata parser  (unchanged from original)
   * ───────────────────────────────────────────── */
  const parseMetadata = metadata => {
    const { dimensions: dimensionsMap, mainStructureMembers: measuresMap } = metadata
    const dimensions = []
    for (const key in dimensionsMap) {
      const dimension = dimensionsMap[key]
      dimensions.push({ key, ...dimension })
    }
    const measures = []
    for (const key in measuresMap) {
      const measure = measuresMap[key]
      measures.push({ key, ...measure })
    }
    return { dimensions, measures, dimensionsMap, measuresMap }
  }

  /* ─────────────────────────────────────────────
   *  Original hierarchy helper  (kept for fallback)
   * ───────────────────────────────────────────── */
  const appendTotal = (data) => {
    data = JSON.parse(JSON.stringify(data))
    const superRoot = {
      dimensions_0: { id: 'total', label: 'Total' },
      measures_0: { raw: 0 }
    }
    data.forEach(d => {
      if (d.dimensions_0.parentId) { return }
      d.dimensions_0.parentId = 'total'
      superRoot.measures_0.raw += d.measures_0.raw
    })
    return [superRoot].concat(data)
  }

  /* ─────────────────────────────────────────────
   *  Build nodes + links from two dimensions
   *
   *  - Auto-assigns a distinct color to each node
   *  - Computes per-node total for % of grand total
   *  - Source labels positioned LEFT, target labels RIGHT
   *  - Each label shows: country name + % of grand total
   *  - Skips rows with null / empty / zero values
   *  - Aggregates duplicate source→target pairs
   * ───────────────────────────────────────────── */
  const buildDimToDimChart = (data, sourceDimKey, targetDimKey, measureKey) => {
    const sourceNodeSet = new Map()  // nodeName → node object
    const targetNodeSet = new Map()  // nodeName → node object
    const linkMap       = new Map()  // "src||tgt" → link object
    const nodeValueMap  = new Map()  // nodeName → accumulated flow value
    let   grandTotal    = 0

    /* ── Pass 1: aggregate links and per-node totals ── */
    data.forEach(row => {
      const sourceLabel = row[sourceDimKey] && row[sourceDimKey].label
      const targetLabel = row[targetDimKey] && row[targetDimKey].label
      const value       = row[measureKey]   && row[measureKey].raw

      // Skip rows missing any required field or with zero/null value
      if (!sourceLabel || !targetLabel || !value) { return }

      const srcName = 'SRC_' + sourceLabel
      const tgtName = 'TGT_' + targetLabel

      // Accumulate per-node totals for % calculation
      nodeValueMap.set(srcName, (nodeValueMap.get(srcName) || 0) + value)
      nodeValueMap.set(tgtName, (nodeValueMap.get(tgtName) || 0) + value)
      grandTotal += value

      // Aggregate duplicate source→target pairs (ECharts requires unique pairs)
      const linkKey = srcName + '||' + tgtName
      const existing = linkMap.get(linkKey)
      if (existing) {
        existing.value += value
      } else {
        linkMap.set(linkKey, { source: srcName, target: tgtName, value })
      }
    })

    /* ── Pass 2: build node objects with auto-color + label ── */
    let colorIndex = 0

    nodeValueMap.forEach((nodeTotal, nodeName) => {
      const isSource   = nodeName.startsWith('SRC_')
      const cleanLabel = nodeName.replace(/^SRC_/, '').replace(/^TGT_/, '')
      const pct        = grandTotal > 0
        ? ((nodeTotal / grandTotal) * 100).toFixed(1)
        : '0.0'
      const color      = NODE_COLORS[colorIndex % NODE_COLORS.length]
      colorIndex++

      const nodeObj = {
        name:      nodeName,
        depth:     isSource ? 0 : 1,
        itemStyle: { color },
        // Label: country name on line 1, % of total on line 2
        // Source nodes: label on LEFT side
        // Target nodes: label on RIGHT side
        label: {
          position:  isSource ? 'left' : 'right',
          formatter: () => `${cleanLabel}\n${pct}%`,
          fontSize:  12,
          color:     '#333'
        }
      }

      if (isSource) {
        sourceNodeSet.set(nodeName, nodeObj)
      } else {
        targetNodeSet.set(nodeName, nodeObj)
      }
    })

    const nodes = [...sourceNodeSet.values(), ...targetNodeSet.values()]
    const links = [...linkMap.values()]

    return { nodes, links, grandTotal }
  }

  /* ─────────────────────────────────────────────
   *  Renderer
   * ───────────────────────────────────────────── */
  class Renderer {
    constructor (root) {
      this._root   = root
      this._echart = null
    }

    async render (dataBinding, props) {
      await getScriptPromisify('https://cdnjs.cloudflare.com/ajax/libs/echarts/5.0.0/echarts.min.js')
      this.dispose()

      if (dataBinding.state !== 'success') { return }

      const { data, metadata } = dataBinding
      const { dimensions, measures } = parseMetadata(metadata)

      const [measure] = measures

      /* ── Decide rendering mode ── */
      const isDimToDim = dimensions.length >= 2

      let nodes, links, grandTotal

      if (isDimToDim) {
        /* ════════════════════════════════════════
         *  TWO-DIMENSION MODE
         * ════════════════════════════════════════ */
        const sourceDim = dimensions[0]
        const targetDim = dimensions[1]

        ;({ nodes, links, grandTotal } = buildDimToDimChart(
          data,
          sourceDim.key,
          targetDim.key,
          measure.key
        ))
      } else {
        /* ════════════════════════════════════════
         *  ORIGINAL SINGLE-DIMENSION / HIERARCHY MODE (fallback)
         * ════════════════════════════════════════ */
        const [dimension] = dimensions
        nodes      = []
        links      = []
        grandTotal = 0

        const augmented = appendTotal(data)
        augmented.forEach(d => {
          const { label, id, parentId } = d[dimension.key]
          const { raw } = d[measure.key]
          grandTotal += raw || 0
          nodes.push({ name: label })

          const dParent = augmented.find(p => p[dimension.key].id === parentId)
          if (dParent) {
            const { label: labelParent } = dParent[dimension.key]
            links.push({ source: labelParent, target: label, value: raw })
          }
        })
      }

      /* ── Resolve dimension/measure display names for headers ── */
      const sourceDimDesc = isDimToDim
        ? (dimensions[0].description || 'Source')
        : 'Hierarchy'
      const targetDimDesc = isDimToDim
        ? (dimensions[1].description || 'Target')
        : ''
      const measureDesc = measure.label || measure.description || 'Amount'

      /* ── Initialise / configure ECharts ── */
      this._echart = echarts.init(this._root)

      this._echart.setOption({

        /* ── Titles: main title + column headers + total legend ── */
        title: [
          {
            // Main chart title
            text:      measureDesc + ' Flow Analysis',
            left:      'center',
            top:       4,
            textStyle: { fontSize: 14, fontWeight: 'bold', color: '#333' }
          },
          {
            // Source column header (top-left)
            text:      sourceDimDesc,
            left:      '1%',
            top:       28,
            textStyle: { fontSize: 11, color: '#888', fontWeight: 'normal' }
          },
          {
            // Target column header (top-right)
            text:      targetDimDesc,
            right:     '1%',
            top:       28,
            textStyle: { fontSize: 11, color: '#888', fontWeight: 'normal' }
          },
          {
            // Grand total legend (bottom-right)
            text:      'Total: ' + formatAmount(grandTotal),
            right:     '1%',
            bottom:    4,
            textStyle: { fontSize: 11, fontWeight: 'bold', color: '#555' }
          }
        ],

        /* ── Tooltip: Source → Target + Amount + % of total ── */
        tooltip: {
          trigger:   'item',
          triggerOn: 'mousemove',
          formatter: (params) => {
            if (params.dataType === 'edge') {
              const src = params.data.source.replace(/^SRC_/, '')
              const tgt = params.data.target.replace(/^TGT_/, '')
              const val = params.data.value
              const pct = grandTotal > 0
                ? ((val / grandTotal) * 100).toFixed(1)
                : '0.0'
              return [
                `<b>${src}</b> → <b>${tgt}</b>`,
                `Amount: <b>${formatAmount(val)}</b>`,
                `Share: <b>${pct}%</b> of total`
              ].join('<br/>')
            }
            if (params.dataType === 'node') {
              const cleanName = (params.data.name || '')
                .replace(/^SRC_/, '')
                .replace(/^TGT_/, '')
              const isSource = (params.data.name || '').startsWith('SRC_')
              const role     = isSource ? sourceDimDesc : targetDimDesc
              return `<b>${cleanName}</b><br/><span style="color:#888">${role}</span>`
            }
            return params.name
          }
        },

        series: [
          {
            type:   'sankey',
            top:    55,   // push chart down to make room for title + headers
            bottom: 25,  // push chart up to make room for total legend
            data:   nodes,
            links:  links,
            emphasis: { focus: 'adjacency' },

            // Global label fallback — individual node label configs take priority
            label: {
              show:     true,
              fontSize: 12,
              formatter: (params) => {
                return (params.name || '')
                  .replace(/^SRC_/, '')
                  .replace(/^TGT_/, '')
              }
            },

            // Levels: color is set per-node in two-dim mode;
            // lineStyle opacity from styling panel is still respected
            levels: [
              {
                depth: 0,
                lineStyle: {
                  color:   'source',
                  opacity: props.depth0Settings.lineOpacity
                }
              },
              {
                depth: 1,
                lineStyle: {
                  color:   'source',
                  opacity: props.depth1Settings.lineOpacity
                }
              },
              {
                depth: 2,
                lineStyle: {
                  color:   'source',
                  opacity: props.depth2Settings.lineOpacity
                }
              },
              {
                depth: 3,
                lineStyle: {
                  color:   'source',
                  opacity: props.depth3Settings.lineOpacity
                }
              }
            ],

            lineStyle: { curveness: 0.7 }
          }
        ]
      })

      /* ── Click / linked-analysis handler ── */
      this._echart.on('click', (params) => {
        const linkedAnalysis = props['dataBindings']
          .getDataBinding('dataBinding')
          .getLinkedAnalysis()

        if (isDimToDim) {
          const sourceDim = dimensions[0]
          const targetDim = dimensions[1]

          if (params.dataType === 'node') {
            /* NODE CLICK → filter the clicked dimension only */
            const rawName   = (params.data.name || '')
            const isSource  = rawName.startsWith('SRC_')
            const cleanName = rawName.replace(/^SRC_/, '').replace(/^TGT_/, '')
            const dim       = isSource ? sourceDim : targetDim
            const dimKey    = dim.key
            const dimId     = dim.id

            const hit = dataBinding.data.find(row => row[dimKey].label === cleanName)
            if (hit) {
              const selection = {}
              selection[dimId] = hit[dimKey].id
              linkedAnalysis.setFilters(selection)
            } else {
              linkedAnalysis.removeFilters()
            }

          } else if (params.dataType === 'edge') {
            /* EDGE CLICK → filter both dimensions simultaneously */
            const srcName = (params.data.source || '').replace(/^SRC_/, '')
            const tgtName = (params.data.target || '').replace(/^TGT_/, '')

            const srcRow = dataBinding.data.find(row => row[sourceDim.key].label === srcName)
            const tgtRow = dataBinding.data.find(row => row[targetDim.key].label === tgtName)

            if (srcRow && tgtRow) {
              const selection = {}
              selection[sourceDim.id] = srcRow[sourceDim.key].id
              selection[targetDim.id] = tgtRow[targetDim.key].id
              linkedAnalysis.setFilters(selection)
            } else {
              linkedAnalysis.removeFilters()
            }

          } else {
            linkedAnalysis.removeFilters()
          }

        } else {
          /* FALLBACK: original single-dimension linked-analysis logic */
          const [dimension] = dimensions
          const dataType    = params.dataType
          const label       = dataType === 'node'
            ? params.data.name
            : dataType === 'edge'
              ? params.data.target
              : ''

          const selectedItem = dataBinding.data.find(item => item[dimension.key].label === label)
          if (selectedItem) {
            const selection = {}
            selection[dimension.id] = selectedItem[dimension.key].id
            linkedAnalysis.setFilters(selection)
          } else {
            linkedAnalysis.removeFilters()
          }
        }
      })
    }

    dispose () {
      if (this._echart) {
        echarts.dispose(this._echart)
      }
    }
  }

  /* ─────────────────────────────────────────────
   *  Web Component HTML template
   * ───────────────────────────────────────────── */
  const template = document.createElement('template')
  template.innerHTML = `
  <style>
      #chart {
          width: 100%;
          height: 100%;
      }
  </style>
  <div id="root" style="width: 100%; height: 100%;">
      <div id="chart"></div>
  </div>
  `

  /* ─────────────────────────────────────────────
   *  Main custom element
   * ───────────────────────────────────────────── */
  class Main extends HTMLElement {
    constructor () {
      super()
      this._shadowRoot = this.attachShadow({ mode: 'open' })
      this._shadowRoot.appendChild(template.content.cloneNode(true))
      this._root     = this._shadowRoot.getElementById('root')
      this._props    = {}
      this._renderer = new Renderer(this._root)
    }

    async onCustomWidgetBeforeUpdate (changedProps) {
      this._props = { ...this._props, ...changedProps }
    }

    async onCustomWidgetAfterUpdate (changedProps) {
      this.render()
    }

    async onCustomWidgetResize (width, height) {
      this.render()
    }

    async onCustomWidgetDestroy () {
      this.dispose()
    }

    render () {
      if (!document.contains(this)) {
        setTimeout(this.render.bind(this), 0)
        return
      }
      this._renderer.render(this.dataBinding, this._props)
    }

    dispose () {
      this._renderer.dispose()
    }
  }

  customElements.define('com-sap-sac-sample-echarts-sankeyyg', Main)
})()
